class Integer
  def falling_factorial(m)
    return (0..(m-1)).inject(1) {|r, k| r*(self - k) }
  end

  def rising_factorial(m)
    return (0..(m-1)).inject(1) {|r, k| r*(self + k) }
  end

  alias permutation falling_factorial

  def factorial
    return self.permutation self
  end

  def combination(m)
    return (self.permutation m) / (m.permutation m)
  end
end

10.permutation 3 #=> 720
10.factorial     #=> 3628800
10.combination 3 #=> 120

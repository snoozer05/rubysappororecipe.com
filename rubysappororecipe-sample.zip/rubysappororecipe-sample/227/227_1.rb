cnt = Fiber.new do
  i = 0
  loop do
    Fiber.yield i   # (1) ここで呼び出し元へ戻る
    # (2) Fiber#resumeを呼ぶと、ここから実行が再開される
    i += 1
  end
end
10.times { p cnt.resume }

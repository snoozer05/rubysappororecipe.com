a = nil
Thread.new do
  a = [1, 2, 3].each
  a.next
end.join

p a.next
#=> t.rb:7:in `next': fiber called across threads (FiberError)
#       from t.rb:7:in `<main>'

require 'rubygems'
require 'bluecloth'

# Markdown記法で書かれたテキスト
text = <<EOP
# Markdown記法のサンプル

ここは本文になります。

## リスト
- 箇条書きレベル1
 - 箇条書きレベル2

## 引用
> ここは引用になります。

## リンク
[Ruby札幌](http://ruby-sapporo.org)
EOP

# Markdown記法で書かれたテキストからHTMLを生成
parser = BlueCloth.new(text)
puts parser.to_html

# wget http://svn.coderepos.org/share/platform/tdiary/plugin/jdate.rb
# で取得しておくこと
require 'jdate'

t = Time.now
t.to_s                         #=> "Thu Jul 23 15:08:09 +0900 2009"
t.strftime("%Y-%m-%d(%a)")     #=> "2009-07-23(Thu)"
t.strftime("%Y年%m月%d日(%J)") #=> "2009年07月23日(木)"

require 'rubygems'
require 'rqr'

RQR::QRCode.create do |qr|
  qr.save("http://ruby-sapporo.org/", "/tmp/qr_ruby-sapporo.png")
end

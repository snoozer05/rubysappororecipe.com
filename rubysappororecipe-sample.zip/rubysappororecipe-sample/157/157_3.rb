require 'rubygems'
require 'rqr'
require 'kconv'
RQR::QRCode.create do |qr|
  qr.save("Ruby札幌のページ http://ruby-sapporo.org/".tosjis,
          "/tmp/qr_ruby-sapporo.jpg")
end

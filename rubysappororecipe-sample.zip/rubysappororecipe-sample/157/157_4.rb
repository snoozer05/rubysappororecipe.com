# p.378
`/usr/bin/qrencode -o /tmp/qr.png http://ruby-sapporo.org`

# 日本語を含めることは可能
require 'kconv'
title = "Ruby札幌のページ".tosjis
`/usr/bin/qrencode -l L -k -o /tmp/qr.png '#{title} http://ruby-sapporo.org'`

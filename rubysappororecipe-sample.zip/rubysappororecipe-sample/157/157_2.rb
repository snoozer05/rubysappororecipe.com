# 誤り訂正レベルなどのオプションを指定するには、
# RQR::QRCode.createかRQR::QRCode.newメソッドの
# 引数で指定する

RQR::QRCode.create(:level => 0) do |qr|
  qr.save("http://ruby-sapporo.org/", "/tmp/qr_ruby-sapporo.png")
end

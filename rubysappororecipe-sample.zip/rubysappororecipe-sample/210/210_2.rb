# p.504 Rakefile
task :convert => FileList["src/*.jpg"].pathmap("%{^src,dest}X.png")

rule ".png" => "%{^dest,src}X.jpg" do |t|
  sh 'convert', t.source, t.name
end

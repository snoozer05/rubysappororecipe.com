# p.502 Rakefile
task :convert => FileList['*.jpg'].ext('png')

rule '.png' => '.jpg' do |t|
  sh 'convert', t.source, t.name
end

# バイナリ形式でデータを書き出す
config = {:port => "3000", :url => "example.com"}
open("config.dat", "w") do |f|
  Marshal.dump(config, f)
end

# シリアライズしたデータを読み戻す
## ファイルに保存しているバイナリからオブジェクトを読み戻す場合
open("config.dat", "r") do |f|
  obj = Marshal.load(f) #=> {:port => "3000", :url => "example.com"}
end

## メモリ上に保存しているバイナリからオブジェクトを読み戻す場合
obj = Marshal.load(Marshal.dump(config)) #=> {:port => "3000", :url => "example.com"}

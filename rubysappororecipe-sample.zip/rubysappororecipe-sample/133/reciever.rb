require 'rinda/tuplespace'

$ts = DRbObject.new_with_uri("druby://localhost:12345")
while tuple = $ts.take(["message", nil])
  p tuple # タプルを表示
  msg = tuple[1]
  $ts.write(["length", msg, msg.length])
end


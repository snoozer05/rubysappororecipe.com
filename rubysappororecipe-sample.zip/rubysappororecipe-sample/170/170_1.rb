require 'logger'

log = Logger.new(STDOUT)
log.debug("This is debug message")
log.info("This is infomation message")
log.warn("This is warning message")

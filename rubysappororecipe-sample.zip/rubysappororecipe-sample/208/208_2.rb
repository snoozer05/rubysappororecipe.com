# p.499 Rakefile
task :default => [:hello]

['hello', 'goodbye'].each do |str|
  desc "say #{str}"
  task str, [:name] do |t, args| # ここで引数を指定する
    args.with_defaults(:name => 'nobody') # 引数のデフォルト値の設定
    if args.name
      sh "echo #{str}, #{args.name}!"
    else
      sh "echo #{str}"
    end
  end
end

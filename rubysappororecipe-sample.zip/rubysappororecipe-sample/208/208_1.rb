# p.498 Rakefile
task :default => [:hello]

['hello', 'goodbye'].each do |str|
  desc "say #{str}"
  task str, [:name] do |t, args| # ここで引数を指定する
    if args.name
      sh "echo #{str}, #{args.name}!"
    else
      sh "echo #{str}"
    end
  end
end

# ディスプレイ
module Display
  # 座標
  class Point
    attr_reader :x, :y

    def initialize(x, y)
      @x, @y = x, y
    end

    # ...
  end
end

# 会員サービス
module CustomerService
  # 会員ポイント
  class Point
    attr_reader :val

    def initialize
      @val = 0
    end

    # ...
  end
end

# モジュール名を指定してクラスを参照する
Display::Point.new(1,2)    #=> #<Display::Point:0x25dc8 @y=2, @x=1>
CustomerService::Point.new #=> #<CustomerService::Point:0x25bc0 @val=0>

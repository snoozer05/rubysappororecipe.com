# entry要素
maker.items.new_item do |entry|
  entry.link = "http://example.com/entry1.html"
  entry.title = "Entry 1"
  entry.updated = Time.parse("2009-2-16 13:00")
  # content要素の利用
  entry.content.type = 'xhtml'
  entry.content.xhtml = '<p>直接マークアップを書くことができます</p>'
end

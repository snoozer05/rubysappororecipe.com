require 'rss'

atom = RSS::Maker.make("atom") do |maker|
  maker.channel.about = 'http://example.com/atom.xml'
  maker.channel.title = 'チャンネルのタイトル'
  maker.channel.link = 'Atom配信フォーマットでサマリ対象とするサイトのURI'
  # Atomはauthor要素とupdated要素が必須
  maker.channel.author = 'ページ作者'
  maker.channel.updated = Time.now

  # entry要素
  maker.items.new_item do |entry|
    entry.link = "http://example.com/entry1.html"
    entry.title = "Entry 1"
    entry.updated = Time.parse("2009-2-16 13:00")
  end
end
puts atom.to_s

Dir.pwd                                      #=> "/Users/muraken/work/ruby-sapporo"
File.expand_path('../../example/sample.cpp') #=> "/Users/muraken/example/sample.cpp"
File.expand_path('../../lib/libexample.dylib', '/usr/local/bin') #=> "/usr/lib/libexample.dylib"
File.expand_path('../lib/libexample.dylib', '/usr/local/bin')    #=> "/usr/local/lib/libexample.dylib"


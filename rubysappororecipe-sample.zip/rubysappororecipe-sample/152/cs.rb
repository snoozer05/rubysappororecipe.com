require 'rubygems'
require 'nokogiri'
require 'open-uri'
require 'rss'

Base = "http://cinema.intercritique.com/comment.cgi"

def comments_url(opts)
  page = opts[:page] || 1
  "#{Base}?new=1&page=#{page}"
end

def comment_url(movie_id, user_id)
  "#{Base}?u=#{user_id}&mid=#{movie_id}"
end

url = comments_url(:page => 1)
html = Nokogiri::HTML(open(url))

# コメント群を配列として取り出す
# 取り出すのにNokogiriの(({xpath}))メソッドを利用
# (({entries}))にはコメントの配列が入る
entries = html.xpath('//table[@class="annitem"]')

rss1_0 = RSS::Maker.make("1.0") do |maker|
  # channel
  maker.channel.about = 'http://recipes.ruby-sapporo.org/feeds/cs.rdf'
  maker.channel.title = 'CinemaScape 新着コメント'
  maker.channel.link = "#{Base}"
  maker.channel.description = '映画批評サイト'

  maker.items.do_sort = true

  entries.each do |entry|
    # コメントひとつひとつに対して、
    # 「映画情報」「ユーザ情報」「コメント内容」を取り出す処理を行う

    # 映画情報
    movie_link = entry.at('td/a')
    movie_title = movie_link.content
    movie_id = movie_link['href'].gsub(/movie\.cgi\?mid=(\d+)/){$1}.to_i
    movie_genre = movie_link['title'].gsub(/.*\[(.*)\]/){$1}.split('/')

    # ユーザ情報
    user_link = entry.at('td[@class="sbj"]/a')
    user_id = user_link['href'].gsub(/user\.cgi\?u=(\d+)/){$1}.to_i
    user_name = user_link.content

    # コメント内容
    review = entry.at('td[@class="txt"]').content.strip
    date_string = entry.at('td[@class="sbj"]/text()').content.gsub(/(\d+)年(\d+)月(\d+)日/){ "#{$1}-#{$2}-#{$3}" }
    published_at = Time.parse(date_string)
    rating = entry.at('td/span')['class'].gsub(/rating(\d)/){$1}.to_i
    permalink = comment_url(movie_id, user_id)

    # 上記の「映画情報」「ユーザ情報」「コメント内容」をもとに
    # フィードのエントリとして登録
    maker.items.new_item do |item|
      item.dc_creator = user_name
      item.link = permalink
      item.title = movie_title << "★" * rating
      item.date = published_at
      item.content_encoded = review
      movie_genre.each{|genre| item.dc_subjects.new_subject{|g| g.content = genre}}
    end
  end
end

File.open('cs.rdf', 'w'){|f| f.write rss1_0.to_s}


# 現在のファイル名(フルパス)と行番号を出力
puts "#{File.expand_path(__FILE__)}: #{__LINE__}"

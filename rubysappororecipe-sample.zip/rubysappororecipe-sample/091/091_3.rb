# クラス判定も併せて行なうのが一般的
class User
  def initialize(name); @name = name; end

  # 名前情報が同値でかつクラスも等しければ同じとみなす
  def ==(other)
    return false unless self.class === other
    return (@name == other.name)
  end
  attr_reader :name
end

# こうしたオブジェクトをハッシュキーに使うといった場合には、
# 加えてObject#eql?メソッドとObject#hashメソッドもオーバーライド
# する必要がある
members = { User.new("TARO") => "Team_A", User.new("HANAKO") => "Team_B" }
members.has_key?(User.new("TARO")) #=> false

class User
  def eql?(other)
    return false unless self.class === other
    return (self.hash == other.hash)
  end
  def hash
    @name.hash
  end
end

members.rehash
members.has_key?(User.new("TARO")) #=> true

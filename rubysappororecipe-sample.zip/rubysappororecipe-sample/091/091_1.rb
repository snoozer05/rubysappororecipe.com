class User
  def initialize(name); @name = name; end
end

user1 = User.new("Taro")
user2 = User.new("HANAKO")
members = [user1, user2]

# オブジェクトが同一なので含まれていると判断
members.include?(user1)            #=> true

# オブジェクトは同値だが同一ではなく含まれていないと判断
members.include?(User.new("Taro")) #=> false

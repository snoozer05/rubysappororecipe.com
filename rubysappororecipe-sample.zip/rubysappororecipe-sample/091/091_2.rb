class User
  def initialize(name); @name = name; end

  # $BL>A0>pJs$,F1CM$G$"$l$PF1$8$H$_$J$9(B
  def ==(other)
    return (@name == other.name)
  end
  attr_reader :name
end

user1 = User.new("Taro")
user2 = User.new("HANAKO")
members = [user1, user2]

members.include?(user1)            # => true
members.include?(User.new("Taro")) # => true

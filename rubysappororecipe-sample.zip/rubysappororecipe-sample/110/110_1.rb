require 'rubygems'
require 'xmpp4r/client'

jid = Jabber::JID.new('tmaeda@gmail.com') # アカウント名を指定する
cl = Jabber::Client.new(jid)
cl.connect
cl.auth('password') # パスワードを設定

# オンライン状態に変更
cl.send(Jabber::Presence.new.set_type(:available))

# コールバックを追加
cl.add_message_callback do |m|
  puts "RECV: " + m.to_s
  if m.body
    reply = Jabber::Message.new(m.from, "#{m.body}ですね、わかります。")
    puts "SEND: " + reply.to_s
    cl.send(reply)
  end

end

sleep

# coding: us-ascii
binary = "\xE6\x96\x87\xE5\xAD\x97\xE5\x88\x97"
binary.encoding                        #=> #<Encoding:ASCII-8BIT>
utf_8 = binary.force_encoding('UTF-8') #=> "文字列"

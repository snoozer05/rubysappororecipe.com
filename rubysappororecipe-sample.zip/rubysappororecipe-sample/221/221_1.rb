# coding: us-ascii
binary = "\xE6\x96\x87\xE5\xAD\x97\xE5\x88\x97"
binary.encoding #=> #<Encoding:ASCII-8BIT>
utf_8 = binary.encode('UTF-8')
#=> "\xE6" from ASCII-8BIT to UTF-8 (Encoding::UndefinedConversionError)

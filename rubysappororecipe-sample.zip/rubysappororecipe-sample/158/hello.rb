require 'rubygems'
require 'inline'

class Hello
  inline do |builder|
    builder.include '<stdio.h>'
    builder.c <<-'EOC'
      void to(char *str) { printf("Hello, %s!\n", str); }
    EOC
  end
end

hello = Hello.new
hello.to("札幌")

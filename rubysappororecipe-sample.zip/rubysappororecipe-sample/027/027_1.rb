require 'bigdecimal'

a = BigDecimal('1.0') #=> #<BigDecimal:2380c,'0.1E1',4(8)>
b = BigDecimal('3.0') #=> #<BigDecimal:23640,'0.3E1',4(8)>
a / b                 #=> #<BigDecimal:231e0,'0.3333333333 333333E0',16(24)>

a = BigDecimal('1.0') #=> #<BigDecimal:22fd8,'0.1E1',4(8)>
b = BigDecimal('3.0') #=> #<BigDecimal:22d44,'0.3E1',4(8)>
a.div(b, 24)          #=> #<BigDecimal:22998,'0.3333333333 3333333333 3333E0',24(36)>

def sub_process
  puts "sub process"
  yield if block_given?
end

def execute_process(&blk)
  sub_process(&blk)
end

execute_process { puts "pass the block" }

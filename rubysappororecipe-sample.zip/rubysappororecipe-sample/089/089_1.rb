class Event
  def initialize(datetime)
    @publish_at = datetime
  end

  # イベントが発行されたか
  def published?
    @publish_at <= DateTime.now
  end
end

# 利用例
require 'rubygems'
require 'activesupport'

# イベント日を 2009/07/24 に設定
datetime = Time.local(2009, 7, 24).to_datetime
e = Event.new(datetime)
if e.published?
  do_something
else
  do_something_else
end

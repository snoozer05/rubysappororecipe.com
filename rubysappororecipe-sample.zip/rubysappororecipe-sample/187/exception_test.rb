class SomeClass
  def foo
  end
end

SomeClass.new.foo(1)

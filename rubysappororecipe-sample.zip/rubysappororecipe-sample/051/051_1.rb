require 'pathname'

# 絶対パスを表現するPathnameオブジェクトを生成
basedir = Pathname.new('/Users/tmaeda/')
abspath = Pathname.new('/Users/muraken/Movies/nicovideo')

# 引数で与えたパスを基準とした相対パスを取得
relpath = abspath.relative_path_from(basedir)
puts relpath #=> "../muraken/Movies/nicovideo"

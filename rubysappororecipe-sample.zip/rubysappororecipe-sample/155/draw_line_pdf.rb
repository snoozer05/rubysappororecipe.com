require 'rubygems'  # gem install cairoをしたときには必要
require 'cairo'

surface = Cairo::PDFSurface.new('line.pdf', 100, 100)
context = Cairo::Context.new(surface)

context.set_source_rgb(0, 0, 1) # 青
context.move_to 0, 0
context.line_to 100, 100
context.stroke

context.show_page
surface.finish

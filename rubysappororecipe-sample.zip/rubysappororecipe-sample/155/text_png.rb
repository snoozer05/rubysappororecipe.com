require 'rubygems'  # gem install cairoをしたときには必要
require 'cairo'

surface = Cairo::ImageSurface.new(Cairo::FORMAT_ARGB32, 100, 100)
context = Cairo::Context.new(surface)

context.set_source_rgb(0, 0, 0) # 黒
context.move_to(25,50)
context.set_font_size 24
context.show_text('ABC')
context.stroke

surface.write_to_png('text.png')

require 'rubygems'  # gem install cairoをしたときには必要
require 'cairo'

surface = Cairo::PDFSurface.new('text.pdf', 100, 100)
context = Cairo::Context.new(surface)

context.move_to(25,50)
context.set_font_size 24
context.show_text('ABC')
context.stroke

context.show_page
surface.finish

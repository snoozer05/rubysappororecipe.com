class Account
  def initialize(authority)
    @authority = authority
  end
  # ...
end

class AccountManager
  def initialize
    @template = {}
  end

  # $B%F%s%W%l!<%H$NEPO?(B
  def add(kind, prototype)
    @template[kind] = prototype
  end

  # $B%F%s%W%l!<%H$+$i%*%V%8%'%/%H$r@8@.(B
  def template(type)
    raise ArgumentError, "#{type}: $BIT@5$J%F%s%W%l!<%H(B" unless @template.key?(type)
    @template[type].clone
  end
end

manager = AccountManager.new
# $B6qBNE*$J%F%s%W%l!<%H$NEPO?(B
manager.add(:normal, Account.new(:admin => false, :file_access => true))
manager.add(:moderator, Account.new(:admin => true, :file_access => true))

# $B%F%s%W%l!<%H$+$i?7$7$$%*%V%8%'%/%H$r@8@.(B
new_user = manager.template(:normal) # => #<Account:0x260d4 @authority={:file_access=>true, :admin=>false}>

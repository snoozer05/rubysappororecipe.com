require 'net/smtp'
require 'rubygems'
require 'tmail'
require 'kconv'
require 'tlsmail'

smtp_server = "localhost"
smtp_port = 587
from_addr = "tmaeda@example.com"
to_addrs = ["snoozer01@example.com", "snoozer02@example.com"]

user="tmaeda"
pass="password"

mail = TMail::Mail.new
mail.to = to_addrs
mail.from = from_addr
mail.subject = "メールのテストです"
mail.date = Time.now
mail.mime_version = '1.0'
mail.set_content_type 'text', 'plain', {'charset'=>'iso-2022-jp'}
mail.body = "こんにちは。\nメールの本文です。".tojis

ssl_smtp = Net::SMTP.start(smtp_server, smtp_port)
ssl_smtp.enable_tls(OpenSSL::SSL::VERIFY_PEER, "/opt/local/etc/openssl/certs")
ssl_smtp.start("example.com", user, pass, :plain) {|smtp|
  smtp.send_mail(mail.to_s, from_addr, *to_addrs)
}


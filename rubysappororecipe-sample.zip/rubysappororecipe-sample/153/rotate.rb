require 'rubygems' # RubyGemsを使わずにインストールした場合は不要
require 'RMagick'

img = Magick::ImageList.new('picture.jpg')
img = img.rotate(90)
img.write('rotate.jpg')

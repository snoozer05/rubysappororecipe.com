require 'rubygems' # RubyGemsを使わずにインストールした場合は不要
require 'RMagick'

path = "picture.jpg"

img = Magick::ImageList.new(path)
img.crop_resized!(100,100)
img.write("#{path}_cropped.png")

img = Magick::ImageList.new(path)
img.resize!(100,150)
img.write("#{path}_resized.png")

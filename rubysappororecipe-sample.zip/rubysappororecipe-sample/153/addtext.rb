require 'rubygems' # RubyGemsを使わずにインストールした場合は不要
require 'RMagick'

img = Magick::ImageList.new("picture.jpg")
text = Magick::Draw.new
text.annotate(img, 0, 0, 0, 60, "Hello, World.") {
  self.gravity = Magick::SouthGravity
  self.pointsize = 48
  self.fill = '#3256B6'
  self.font_weight = Magick::BoldWeight
}
img.write('annotate.jpg')

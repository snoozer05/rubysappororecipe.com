# 基本的な操作
require 'rubygems'
require 'pg'

conn = PGconn.connect('127.0.0.1', 5432, '', '', 'example', 'user', 'password')

begin
  conn.exec("create table users( id serial, name text )")
  conn.exec("insert into users(name) values ('snoozer05')")
  conn.exec("insert into users(name) values ('dara')")
  res = conn.exec("select * from users")
  res.each {|user| p user}
ensure
  conn.close
end

# バインド変数の利用（p.214）
## バインド変数を含めたプリペアードステートメントを作成
conn.prepare("stmt", "select * from users where name=$1")

## バインド変数に値を設定しプリペアードステートメントを発行
res = conn.exec_prepared("stmt", ["snoozer05"])
res[0] #=> {"name"=>"snoozer05", "id"=>"1"}

File.fnmatch?('ruby*', 'rubyrecipe.tex')     #=> true
File.fnmatch?('ruby?.tex', 'rubyrecipe.tex') #=> false
File.fnmatch?('ruby.tex', 'rubyrecipe.tex')  #=> false
File.fnmatch?('ruby', 'rubyrecipe.tex')      #=> false

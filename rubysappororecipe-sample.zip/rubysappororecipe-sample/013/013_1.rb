# 注：このファイルは .irbrc に行なう設定内容を示しています
require 'rubygems'
require 'wirble'

# Wirbleを初期化（Tab補完、シンタックスハイライトなどを有効化）して開始する
Wirble.init

# 実行結果の出力を色付きで表示する
Wirble.colorize

# デフォルトのプロンプトを使いたい場合には、以下のコメントを外す
# Wirble.init(:skip_prompt => :DEFAULT)

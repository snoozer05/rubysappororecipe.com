# 名前を表現するオブジェクト
class Name < Struct.new(:first, :last)
  undef first=, last=, []=
end

# バリューオブジェクトの使用例
class Customer
  attr_accessor :name, :mail

  def initialize(name, mail)
    @name, @mail = name, mail
  end
end

name = Name.new("Koji", "SHIMADA")
mail = "shimada@example.com"

customer = Customer.new(name, mail)

# 値の参照は個別にできても、更新は個別にできない
customer.name.last           # => "SHIMADA"
customer.name.last = "MAEDA" #=> NoMethodError

# 名前を変更したい場合はオブジェクトごと変更
customer.name = Name.new("Tomoki", "MAEDA")
customer.name.last           # => "MAEDA"

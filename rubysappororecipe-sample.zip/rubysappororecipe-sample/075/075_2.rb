# 参照透過性を保証するためのメソッドをStructクラスに追加
class Struct
  # 値を更新するメソッドを抽出して定義を取り消す
  def self.acts_as_immutable
    class_eval do
      members.each {|m| undef_method "#{m}="}
      undef []=
    end
  end
end

# 拡張したStructクラスを利用したバリューオブジェクトの表現
class Name < Struct.new(:first, :last)
  acts_as_immutable
end

# 住所を表現するバリューオブジェクト
class Address < Struct.new(:zip, :prefecture, :city)
  acts_as_immutable
end

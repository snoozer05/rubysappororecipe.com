a = [1,2,3]
a.class #=> Array

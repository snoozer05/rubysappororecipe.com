require 'win32ole'
require 'date'

word = WIN32OLE.new "Word.Application"
doc = word.Documents.Open('C:/rubyrecipe/sample.dot')
doc.CustomDocumentProperties("Applicant").Value = "���c�_��"
doc.CustomDocumentProperties("ContentOfApplication").Value = "�D�yRuby��c01�̊J�Ô�p�ɂ��Ă̐\��"
doc.CustomDocumentProperties("DateOfApplication").Value = Date.today.to_s
doc.Fields.Update
doc.SaveAs('C:/rubyrecipe/sample.doc')
doc.Close
word.Quit

class SampleClass; end
sample = SampleClass.new

ObjectSpace.each_object(SampleClass) {|obj| p obj}
#=> #<SampleClass:0x10ff5cc>

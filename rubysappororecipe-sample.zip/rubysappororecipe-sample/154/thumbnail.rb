require 'rubygems'
require 'image_science'

path = "picture.jpg"

ImageScience.with_image(path) do |img|
  img.cropped_thumbnail(100) do |thumb|
    thumb.save "#{path}_cropped.png"
  end
  img.thumbnail(100) do |thumb|
    thumb.save "#{path}_thumb.png"
  end
  img.resize(100,150) do |resized|
    resized.save "#{path}_resized.png"
  end
end

require 'car'

car = Car.describe_as.
          box.
          tap{|car| p car}.
          length(50.5).
          includes(Equipment::LADDER)
#=> #<Car:0x81b2288 @desc={:type=>"box"}>

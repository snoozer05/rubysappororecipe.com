class Car
  def self.describe_as
    Car.new
  end

  def initialize
    @desc = {}
  end

  def box
    type("box")
  end

  def length(value)
    @desc[:length] = value
    self
  end

  def includes(equip)
    @desc[:equipment] = equip
    self
  end

  #...
  private
  def type(value)
    @desc[:type] = value
    self
  end

  #...
end


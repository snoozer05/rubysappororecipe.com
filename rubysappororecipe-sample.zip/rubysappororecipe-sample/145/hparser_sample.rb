require 'rubygems'
require 'hparser'

# はてな記法で書かれたテキスト
text = <<EOP
*[misc]はてな記法のサンプル
ここは本文になります。
**リスト
-箇条書きレベル1
--箇条書きレベル2
-箇条書き(その2)
**表組み
|りんご|バナナ|みかん|
|1個|2個|3個|
EOP

# はてな記法で書かれたテキストからHTMLを生成
# HParser::Parserオブジェクトを生成
parser = HParser::Parser.new
# parseメソッドで解析した結果を元にHTMLを生成
html = parser.parse(text).map{|e| e.to_html }.join("\n")
puts html

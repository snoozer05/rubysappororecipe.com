Complex(1, 1).abs         #=> 1.4142135623730951
Complex(1, 1).abs2        #=> 2
Complex(1, 1).phase       #=> 0.78539816339744828
Complex.polar(1, 2).polar #=> [1.0, 2.0]
Complex(1, 1).conj        #=> (1-1i)

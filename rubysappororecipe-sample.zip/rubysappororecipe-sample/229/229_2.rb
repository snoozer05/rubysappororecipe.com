# 実部を取り出す
Complex(2, 3).real #=> 2

# 虚部を取り出す
Complex(2, 3).imag #=> 3

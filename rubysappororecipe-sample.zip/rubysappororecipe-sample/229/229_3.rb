Complex(2, 3).to_s    #=> "2+3i"
Complex(2, 3).inspect #=> "(2+3i)"

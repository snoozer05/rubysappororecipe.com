#Hiki記法で書かれたテキストからHTMLを生成する
require 'rubygems'
require 'hikidoc'

# Hiki記法で書かれたテキスト
text = <<EOP
!見出し
"" ここは引用です
* ここは箇条書きレベル1です
** ここは箇条書きレベル2です
ここは本文になります
EOP

# Hiki記法で書かれたテキストからHTMLを生成
puts HikiDoc.to_html(text)

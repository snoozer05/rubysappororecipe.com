require 'net/http'

Net::HTTP.version_1_2   # おまじない
url = URI.parse('http://rubyrecipe.ruby-sapporo.org/net-http/index.html')
req = Net::HTTP::Get.new(url.path)
res = Net::HTTP.start(url.host, url.port) {|http|
  http.request(req)
}

if res.class == Net::HTTPOK
  puts res.body
else
  puts "#{res.code}: #{res.message}"
end

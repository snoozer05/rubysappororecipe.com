class Book
  attr_reader :title, :author, :owner

  def initialize(title, author, owner=:mine)
    @title, @author, @owner = title, author, owner
  end
end

book = Book.new("Ruby逆引きレシピ", "Ruby札幌")
book.title  #=> "Ruby逆引きレシピ"
book.author #=> "Ruby札幌"
book.owner  #=> :mine

# コレクションを保持している場合には注意が必要(p.160)
class Bookshelf
  attr_reader :books

  def initialize
    @books = [Book.new("Ruby逆引きレシピ", "Ruby札幌"),
              Book.new("初めてのRuby", "yugui", :brother)]
  end
end

# 参照先から内部状態を変更できてしまう！
bookshelf = Bookshelf.new
books = bookshelf.books #=> [#<Book:0x25968 @owner=:mine, @author="Ruby札幌", @title="Ruby逆引きレシピ">, #<Book:0x25918 @owner=:brother, @author="yugui", @title="初めてのRuby">]
books << "hogehoge"
bookshelf.books         #=> [#<Book:0x25968 @owner=:mine, @author="Ruby札幌", @title="Ruby逆引きレシピ">, #<Book:0x25918 @owner=:brother, @author="yugui", @title="初めてのRuby">, "hogehoge"]

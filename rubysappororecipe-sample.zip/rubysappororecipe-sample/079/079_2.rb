class Book
  attr_reader :title, :author, :owner

  def initialize(title, author, owner=:mine)
    @title, @author, @owner = title, author, owner
  end
end

# コレクションを保持しているインスタンス変数については、
# インスタンス変数を直接参照することは許さず、
# 利用する側の目的を満たすメソッドをそれぞれ用意する
class Bookshelf
  def initialize
    @books = [Book.new("Ruby逆引きレシピ", "Ruby札幌"),
              Book.new("初めてのRuby", "yugui", :brother)]
  end

  def my_books
    @books.select {|book| book.owner == :mine}
  end
end

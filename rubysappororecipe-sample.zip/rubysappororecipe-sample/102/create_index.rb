# データの投入
require 'senna'

index = Senna::Index::create('senna_index',
                             0,
                             Senna::INDEX_NORMALIZE|Senna::INDEX_NGRAM,
                             0,
                             Senna::ENC_UTF8)
# データを投入する
index.upd("060-0941", nil, "北海道札幌市中央区旭ケ丘")
index.upd("060-0041", nil, "北海道札幌市中央区大通東")

index.close

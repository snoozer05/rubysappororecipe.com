# データの検索
require 'senna'

index = Senna::Index::open('senna_index')
results = index.select('札幌')
p results.nhits # ヒット数を表示
results.each do |key, score|
  p [key, score] # 検索結果を表示
end
index.close

# バインド変数や名前付きプレースホルダの利用（p.210）
## プレースホルダとバインド変数を利用してSQLを発行
sql = "insert into users (id, login, mail) values (?, ?, ?)"
db.execute(sql, 1, "mrkn", "mrkn@example.com")

## 名前付きプレースホルダを利用してSQLを発行
sql = "insert into users (id, login, mail) values (:id, :login, :mail)"
db.execute(sql, :id => 2, :login => 'elim', :mail => 'elim@example.com')

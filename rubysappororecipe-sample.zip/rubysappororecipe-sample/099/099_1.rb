# 基本的な操作
require 'rubygems'
require 'sqlite3'

db = SQLite3::Database.new("app_data.db")

begin
  db.execute("select * from users") do |row|
    p row
  end
ensure
  db.close
end

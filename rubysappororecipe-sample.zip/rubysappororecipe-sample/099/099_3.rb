# SQLをまとめて発行
sql=<<SQL
  drop table if exists users;
  create table users (
    id integer,
    login text,
    mail text
  );
  insert into users (id, login, mail) values (1, 'admin', 'admin@example.com');
SQL

db.execute_batch(sql)

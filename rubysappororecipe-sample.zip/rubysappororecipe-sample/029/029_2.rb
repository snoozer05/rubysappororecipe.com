require 'rubygems'
require 'measure/length'
require 'measure/support'

Measure.short_form do
  10.m - 10.cm  #=> #<Measure:0x52e8ec @value=9.9, @unit=:m>
end

require 'rubygems'
require 'measure/length'

p Measure(10, :m)                    # => #<Measure:0x542c5c @unit=:m, @value=10>
p Measure(10, :m) - Measure(10, :cm) # => #<Measure:0x53000c @unit=:m, @value=9.9>

require 'net/smtp'
require 'rubygems'
require 'tmail'
require 'kconv'

smtp_server = "localhost"
smtp_port = 25
from_addr = "tmaeda@example.com"
to_addrs = ["snoozer01@example.com", "snoozer02@example.com"]

mail = TMail::Mail.new
mail.to = to_addrs
mail.from = from_addr
mail.subject = "メールのテストです"
mail.date = Time.now
mail.mime_version = '1.0'
mail.set_content_type 'text', 'plain', {'charset'=>'iso-2022-jp'}
mail.body = "こんにちは。\nメールの本文です。".tojis

Net::SMTP.start(smtp_server, smtp_port) do |smtp|
  smtp.send_mail(mail.to_s, from_addr, *to_addrs)
end

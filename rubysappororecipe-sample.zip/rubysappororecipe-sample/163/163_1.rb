require 'java'

module Java
  module Util
    include_package 'java.util'
  end
end

h = Java::Util::HashMap.new
#=> #<Java::JavaUtil::HashMap:0x849077 @java_object={}>
h[:name] = "shimada"
h.get(:name) #=> "shimada"
h[:name]     #=> "shimada"

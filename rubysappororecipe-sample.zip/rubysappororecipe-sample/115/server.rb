require 'webrick'
include WEBrick

server = HTTPServer.new(
  :DocumentRoot => File.join(Dir.pwd, "www"),
  :Port => 10080
)
trap("INT"){ server.shutdown }
server.start


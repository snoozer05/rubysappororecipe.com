require 'rubygems'
require 'open-uri-mapping'

url = 'http://rubyrecipe.ruby-sapporo.org/feeds/cs.rdf'
# 上記のURIにアクセスすると/tmp/cs.rdfを開くようにマッピングを変更
URI::Mapping[url] = '/tmp/cs.rdf'
open(url)


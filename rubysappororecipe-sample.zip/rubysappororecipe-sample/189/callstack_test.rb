class SomeClass
  def foo
    bar
  end

  def bar
    baz
  end

  def baz
    debugger
    puts caller(0)
  end
end

SomeClass.new.foo

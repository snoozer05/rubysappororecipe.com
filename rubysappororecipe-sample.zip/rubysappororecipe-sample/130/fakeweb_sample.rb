require 'rubygems'
require 'fakeweb'

# FakeWeb.allow_net_connect = false

uri = URI.parse("http://ruby-sapporo.org/")

FakeWeb.register_uri(:get, uri, :string => "body string")

FakeWeb.register_uri(:head, uri, :response => "dummy_header")

response = nil
Net::HTTP.start(uri.host, uri.port) do |http|
  response = http.get("/")
end
p response.body

response = nil
Net::HTTP.start(uri.host, uri.port) do |http|
  response = http.head("/")
end
p response.to_hash

class SampleApp
  def initialize(context)
    @context = context
  end
  attr_reader :context
end

context = {:url => "http://example.com", :port => 3000, :lang => "ja"}
app = SampleApp.new(context)
app.context #=> {:url=>"http://example.com", :port=>3000, :lang=>"ja"}

# contextを操作することでappの内部状態を変更できてしまう
context[:port] = 389 #=> 389
context              #=> {:url=>"http://example.com", :port=>389, :lang=>"ja"}
app.context          #=> {:url=>"http://example.com", :port=>389, :lang=>"ja"}

# 読み出したcontext情報を操作することでappの内部情報を変更できてしまう
c = app.context #=> {:url=>"http://example.com", :port=>389, :lang=>"ja"}
c[:lang] = "us" #=> "us"
c               #=> {:url=>"http://example.com", :port=>389, :lang=>"us"}
app.context     #=> {:url=>"http://example.com", :port=>389, :lang=>"us"}

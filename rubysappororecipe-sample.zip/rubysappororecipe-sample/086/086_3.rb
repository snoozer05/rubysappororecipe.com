# $B?<$$%3%T!<$K$h$kKI8fE*%3%T!<$N<B8=(B

class SampleApp
  def initialize(context)
    @context = Marshal.load(Marshal.dump(context))
  end

  def context
    Marshal.load(Marshal.dump(@context))
  end
end

context = {:url => "http://example.com", :port => 3000, :lang => "ja"}
app = SampleApp.new(context)
app.context     #=> {:url=>"http://example.com", :port=>3000, :lang=>"ja"}

context[:port] = 389
context         #=> {:url=>"http://example.com", :port=>389, :lang=>"ja"}
app.context     #=> {:url=>"http://example.com", :port=>3000, :lang=>"ja"}

c = app.context
c[:lang] = "us"
c               #=> {:url=>"http://example.com", :port=>3000, :lang=>"us"}
app.context     #=> {:url=>"http://example.com", :port=>3000, :lang=>"ja"}

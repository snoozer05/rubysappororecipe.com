# 浅いコピーによる防御的コピーの実現

class SampleApp
  def initialize(context)
    @context = context.clone
  end

  def context
    @context.dup
  end
end

context = {:url => "http://example.com", :port => 3000, :lang => "ja"}
app = SampleApp.new(context)
app.context #=> {:url=>"http://example.com", :port=>3000, :lang=>"ja"}

context[:port] = 389 #=> 389
context              #=> {:url=>"http://example.com", :port=>389, :lang=>"ja"}
app.context          #=> {:url=>"http://example.com", :port=>3000, :lang=>"ja"}

c = app.context #=> {:url=>"http://example.com", :port=>3000, :lang=>"ja"}
c[:lang] = "us" #=> "us"
c               #=> {:url=>"http://example.com", :port=>3000, :lang=>"us"}
app.context     #=> {:url=>"http://example.com", :port=>3000, :lang=>"ja"}

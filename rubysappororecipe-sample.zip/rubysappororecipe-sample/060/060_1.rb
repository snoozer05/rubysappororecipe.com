require 'yaml'

config = YAML.load_file("config.yml")
config                 #=> {"user"=>{"name"=>"taro", "admin"=>false, "mails"=>["taro@example.jp", "taro@example.com"], "pass"=>"himitsu"}}
config["user"]["name"] #=> "taro"

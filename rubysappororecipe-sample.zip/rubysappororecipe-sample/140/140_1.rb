require 'rubygems'
require 'uuidtools'

# バージョン1
UUIDTools::UUID.timestamp_create
#=> #<UUID:0x-24484b3c UUID:b98b08e2-1864-11de-a474-001d7d42a416>

# バージョン3
UUIDTools::UUID.md5_create(UUIDTools::UUID_DNS_NAMESPACE, "example.com")
#=> #<UUID:0x-24395186 UUID:9073926b-929f-31c2-abc9-fad77ae3e8eb>

# バージョン4
UUIDTools::UUID.random_create
#=> #<UUID:0x-24485b68 UUID:f6b96968-079c-4b49-82ed-5dae46adb339>

# バージョン5
UUIDTools::UUID.sha1_create(UUIDTools::UUID_DNS_NAMESPACE, "example.com")
#=> #<UUID:0x-2439a1f4 UUID:cfbff0d1-9375-5685-968c-48ce8b15ae17>

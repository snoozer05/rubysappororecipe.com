require 'rubygems'
require 'active_ldap'

ActiveLdap::Base.setup_connection(
  :host => 'ldap.example.com',
  :port => 389,
  :base => 'dc=example,dc=com',
  :bind_dn => 'cn=root,dc=example,dc=com',
  :password_block => Proc.new{'secret'},
  :allow_anonyous => false
)

class Member < ActiveLdap::Base
  ldap_mapping :dn_attribute => 'uid', :prefix => 'ou=People', :scope => :one
end

# uidが'snoozer05'のエントリのcnを変更して保存する
snoozer05 = Member.find("snoozer05")
snoozer05.cn = "SHIDARA Yhoji"
snoozer05.save!

# uidが'snoozer06'のエントリが存在するか
Member.exists?("snoozer06")


class Member < ActiveLdap::Base
  ldap_mapping :dn_attribute => 'uid', :prefix => 'ou=People', :scope => :one
  belongs_to :groups, :class_name => 'Group', :many => 'memberUid', :primary_key => 'uid'
end

class Group < ActiveLdap::Base
  ldap_mapping :dn_attribute => 'gid', :prefix => 'ou=Group', :scope => :one
  has_many :members, :class_name => 'Member', :wrap => 'memberUid', :primary_key => 'uid'
end

staff = Group.find('staff')
staff.members.map {|m| m.uid }

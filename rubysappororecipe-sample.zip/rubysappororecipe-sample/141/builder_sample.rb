require 'rubygems'
require 'nokogiri'

builder = Nokogiri::HTML::Builder.new{
  html{
    body{
      h1{ text "nokogiri 1.2.3 リリース" }
      text "こんいちは！アーロンです！ "
    }
  }
}
puts builder.to_html


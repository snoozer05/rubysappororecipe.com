class User
  attr_accessor :id, :name
  def initialize(id, name)
    @id, @name = id, name
  end
end

user1 = User.new(1, "Matz")
user2 = User.new(2, "Dave")
users = [user1, user2]

p user1 #=> #<User:0x59da8 @id=1, @name="Matz">
p user2 #=> #<User:0x56a7c @id=2, @name="Dave">
p users #=> [#<User:0x59da8 @id=1, @name="Matz">, #<User:0x56a7c @id=2

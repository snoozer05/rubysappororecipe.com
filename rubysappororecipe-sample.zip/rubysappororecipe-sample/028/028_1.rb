require 'decimal'

Decimal(1)     #=> Decimal(1)
Decimal('1.0') #=> Decimal(1.0)

Decimal("1e+5") + Decimal("0.2e-24")   #=> Decimal(100000.0000000000000000000000002)
Decimal("1e+5") * Decimal("0.2e-24")   #=> Decimal(0.00000000000000000002)

Decimal(1).divide(Decimal(3), 12)      #=> Decimal::ArithmeticError: rounding necessary
Decimal(1).divide(Decimal(3), 12, Decimal::ROUND_UP)        #=> Decimal(0.333333333334)
Decimal(1).divide(Decimal(3), 12, Decimal::ROUND_DOWN)      #=> Decimal(0.333333333333)
Decimal(1).divide(Decimal(3), 12, Decimal::ROUND_FLOOR)     #=> Decimal(0.333333333333)
Decimal(1).divide(Decimal(3), 12, Decimal::ROUND_CEILING)   #=> Decimal(0.333333333334)
Decimal(5).divide(Decimal(9), 12, Decimal::ROUND_HALF_UP)   #=> Decimal(0.555555555556)
Decimal(5).divide(Decimal(9), 12, Decimal::ROUND_HALF_DOWN) #=> Decimal(0.555555555555)
Decimal(1).divide(Decimal(3), 12, Decimal::ROUND_HALF_EVEN) #=> Decimal(0.333333333333)
Decimal(4).divide(Decimal(9), 12, Decimal::ROUND_HALF_EVEN) #=> Decimal(0.444444444444)
Decimal(5).divide(Decimal(9), 12, Decimal::ROUND_HALF_EVEN) #=> Decimal(0.555555555556)
Decimal(2).divide(Decimal(3), 12, Decimal::ROUND_HALF_EVEN) #=> Decimal(0.666666666667)

#!/usr/bin/ruby

require 'rubygems'
require 'ruby-debug'; Debugger.start

def pow(x, n)
  debugger # デバッガを起動
  raise if n < 0
  if n == 0
    return 1
  else
    return pow(x, n - 1) * x
  end
end


puts pow(ARGV[0].to_i, ARGV[1].to_i)
#

require 'logger'

log = Logger.new(STDOUT)
log.level = Logger::INFO # INFO以上のログのみ出力

log.debug("This is debug message")
log.info("This is infomation message")
log.warn("This is warning message")


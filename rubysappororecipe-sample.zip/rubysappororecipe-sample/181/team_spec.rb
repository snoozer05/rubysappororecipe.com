require 'person'
require 'team'

describe Team, "include admin" do
  before do
    admin = Person.new
    admin.should_receive(:admin?).and_return(true)

    @team = Team.new
    @team.add(admin)
  end

  it "should has_admin? return true" do
    @team.has_admin?.should be_true
  end
end

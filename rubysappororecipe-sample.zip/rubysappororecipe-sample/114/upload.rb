require 'rubygems'
require 'net/ssh'
require 'net/scp'
require 'pit'

host = 'ruby-sapporo.org'
conf = Pit.get(host, :require => { "username" => "username", "password" => "password"})

files = ['cs.rdf', 'feed1.atom', 'feed2.rdf']
dest_dir = "/var/www/rubyrecipe/feeds"

Net::SSH.start(host, conf['username'], :password => conf['password']) do |ssh|
  # 一度リモートホストのホームディレクトリにファイルをコピーしておく
  files.each{ |f| ssh.scp.upload!(f, "~/", :preserve => true) }
  puts "files hove been copied"

  prompt = "password:"
  cmd = "sudo -p '#{prompt}' mv #{files.join(" ")} #{dest_dir}"
  # Net::SSH#open_channelメソッドにょりリモートホスト上でコマンドを実行
  ssh.open_channel do |ch|
    ch.exec(cmd) do |ch, success|
      raise "Error" unless success
      # sudoコマンドのパスワードのプロンプトは標準エラー出力に出るので
      # Net::SSH::Connection::Channel#on_extened_dataメソッドを利用
      ch.on_extended_data do |ch, type, data|
        ch.send_data("#{conf["password"]}\n") if type == 1 and data =~ /#{prompt}/
      end
    end
  end
  ssh.loop
end


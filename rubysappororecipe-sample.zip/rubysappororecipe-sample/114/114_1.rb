require 'rubygems'
require 'net/scp'

host, user = %w( ruby-sapporo.org noplans )
remote_path = '~/'

# ファイルを1つだけアップロード
file = 'file0'
Net::SCP.upload!(host, user, file, remote_path)

# ブロックを使うと進捗状況をブロック引数から取得できる
file = 'file0'
Net::SCP.upload!(host, user, file, remote_path) do |ch, name, sent, total|
  puts "#{name}: #{sent}/#{total}"
end

# 複数のファイルをアップロード
files = %w( fil1 file2 file3 )
Net::SCP.start(host, user) do |session|
  files.each {|f| session.upload(f, remote_path) }
end

# ディレクトリ構造ごとアップロード
local_path = File.join(File.expand_path('.'), 'localdir')
Net::SCP.upload!(host, user, local_path, remote_path, :recursive => true)


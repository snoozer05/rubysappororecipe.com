require 'pstore'

db = PStore.new("history_data")
db.transaction do
  db["history"] ||= []
  db["history"] << Time.now # 現在の時刻を追加
end

db.transaction(true) do
  # 表示する
  p db["history"]
end

require 'pstore'

db = PStore.new("counter_data")
db.transaction do
  if db["counter"]
    db["counter"] += 1 # すでに値が入っている場合は加算する
  else
    db["counter"] = 0  # 最初は0で初期化する
  end
end

db.transaction(true) do
  # 表示する
  p db["counter"]
end

class Command
  # 振る舞いを決定
  def initialize(command)
    @command = command
  end

  # インスタンスごとに振る舞いを切り替えて実行
  def execute
    method(@command).call
  end

  # 実際に実行される具体的なメソッド
  def paste
    puts "貼付けに関する振る舞いを実装"
  end

  def copy
    puts "コピーに関する振る舞いを実装"
  end
end

menu = [Command.new(:paste), Command.new(:copy)]

menu.each {|command|
  command.execute
}

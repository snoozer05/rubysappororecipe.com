require 'zlib'

src = "Hello, world!" * 100

puts "before: %d bytes" % src.size

Zlib::GzipWriter.open('hello.txt.gz') do |gz|
  gz.write src
end

puts "after: %d bytes" % File.size('hello.txt.gz')

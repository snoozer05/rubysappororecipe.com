require 'zlib'

Zlib::GzipReader.open('hello.txt.gz') do |gz|
  text = gz.read
  puts text
end

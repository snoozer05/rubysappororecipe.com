require 'rubygems'
require 'sequel'
$KCODE = 'u'
DB = Sequel.sqlite('database.sqlite3')

# O/Rマッピング
class Zipcode < Sequel::Model
end

## テーブル名を明示する場合には、Sequel::Modelの引数にテーブル名を与える
# class Zipcode < Sequel::Model(:zipcodes)
# end

# カラムの取り出し
Zipcode["1020072"] #=> #<Zipcode @values={:address=>"千代田区飯田橋", :zipcode=>"1020072", :prefecture=>"東京都"}>
Zipcode.filter(:prefecture => "北海道").each do |z|
  p z.address
end

# メソッドの追加
class Zipcode < Sequel::Model
  def full_address
    prefecture + address
  end
end

Zipcode["1020072"].full_address #=> "東京都千代田区飯田橋"

# レコードの更新
asahigaoka = Zipcode["0640941"] #=> #<Zipcode @values={:address=>"札幌市中央区旭丘", :zipcode=>"0640941", :prefecture=>"北海道"}>
asahigaoka.address = "札幌市中央区旭ヶ丘"
asahigaoka.save

Zipcode["0640941"] #=> #<Zipcode @values={:address=>"札幌市中央区旭ヶ丘", :zipcode=>"0640941", :prefecture=>"北海道"}>

# レコードの削除
asahigaoka.delete
Zipcode.count #=> 2

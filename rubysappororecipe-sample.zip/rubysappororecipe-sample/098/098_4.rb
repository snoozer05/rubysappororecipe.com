require 'rubygems'
require 'sequel'
$KCODE = 'u'
DB = Sequel.sqlite('database.sqlite3')

# 直接SQLを記述する(p.207)
## CREATE文でテーブルを作成
DB << 'CREATE TABLE test_table (id INTEGER, text TEXT)'

## SELECT文で郵便番号を取得
DB['SELECT * FROM zipcodes'].each do |row|
  p row
end

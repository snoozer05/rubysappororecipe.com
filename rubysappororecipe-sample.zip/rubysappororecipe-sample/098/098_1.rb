# データベースに接続する

require 'rubygems'
require 'sequel'

## SQLite3のオンメモリデータベースを利用
DB = Sequel.sqlite

## ファイルを指定してオープン
DB = Sequel.sqlite("database.sqlite3")

## URIを利用（ユーザ名user、パスワードpasswordでlocalhostにある
## PostgreSQLのmy_dbデータベースに接続する場合）
DB = Sequel('postgres://user:password@localhost/my_db')


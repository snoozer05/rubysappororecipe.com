require 'rubygems'
require 'sequel'
$KCODE = 'u'
DB = Sequel.sqlite('database.sqlite3')

# 基本的な操作
## テーブルの作成
DB.create_table :zipcodes do
  text :zipcode, :primary_key => true
  text :prefecture, :index => true
  text :address
end

zipcodes = DB[:zipcodes]
zipcodes.count #=> 0

# データの追加
zipcodes << ["0640941", "北海道", "札幌市中央区旭丘"]
zipcodes << {:zipcode => "0600041", :prefecture => "北海道", :address => "札幌市中央区大通東"}
zipcodes << {:zipcode => "1020072", :prefecture => "東京都", :address => "千代田区飯田橋"}

# データの検索
zipcodes.where(:zipcode => "0600041").first #=> {:zipcode=>"0600041", :prefecture=>"北海道", :address=>"札幌市中央区大通東"}
zipcodes.filter(:prefecture => "北海道").all #=> [{:zipcode=>"0640941", :prefecture=>"北海道", :address=>"札幌市中央区旭丘"}, {:zipcode=>"0600041", :prefecture=>"北海道", :address=>"札幌市中央区大通東"}]

hokkaido = zipcodes.filter(:prefecture => "北海道") #=> #<Sequel::SQLite::Dataset: "SELECT * FROM `zipcodes` WHERE (`prefecture` = '北海道')">

## クエリにorderを指定
hokkaido_ordered = hokkaido.order_by(:zipcode) #=> #<Sequel::SQLite::Dataset: "SELECT * FROM `zipcodes` WHERE (`prefecture` = '北海道') ORDER BY `zipcode`">

## Datasetをさらに絞り込む
hokkaido.filter(:address.like'%大通%') #=> #<Sequel::SQLite::Dataset: "SELECT * FROM `zipcodes` WHERE ((`prefecture` = '北海道') AND (`address` LIKE '%大通%'))">


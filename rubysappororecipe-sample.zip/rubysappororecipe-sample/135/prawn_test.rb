#!/usr/bin/ruby -Ku

require 'rubygems'
require 'prawn'

Prawn::Document.generate("test.pdf", :page_size => "A4") do
  font "ipamp.ttf" # IPA フォントを指定
  text_options.update(:wrap => :character) # 文字単位で自動改行

  ###
  # 日付
  time = Time.now.strftime("%Y年%m月%d日")
  font.size = 9 # フォントサイズを指定して
  text time, :align => :right # 右寄せでテキストを描画

  ###
  # タイトル
  title = "お見積書"
  font.size = 16
  text title, :align => :center # センタリングも可能

  ###
  # 宛先
  move_down(30) # 描画位置を現在位置から30ポイント下げてから
  font.size = 12
  text "(株)レシピ出版　御中" # テキストの描画
  move_down(2)
  stroke_horizontal_line(bounds.left,# 左端から
                         # 中央より30ポイント左まで水平線を引く
                         bounds.width / 2 - 30)


  ###
  # 差出人
  move_down(10)
  font.size = 10
  text "(株)レシピシステム", :align => :right, :size => 12
  text "〒123-4567 北海道札幌市中央区北1条西2丁目3-4", :align => :right
  text "レシピビル8F", :align => :right
  text "TEL 011-222-XXXX / FAX 011-222-YYYY", :align => :right

  ###
  # 合計金額
  move_down(10)
  text "下記の通りお見積もり申し上げます。よろしくお願い致します。"
  move_down(2)
  table([["お見積もり金額", "￥12,600,000-"]], # 表の作成
        :widths => # 各カラムの幅をハッシュで指定
        { 0 => bounds.width * 0.4, 1 => bounds.width * 0.6 },
        :align => # 各カラムのalignをハッシュで指定
        { 0 => :center, 1 => :right})

  ###
  # 内訳
  move_down(10)
  text "内訳"
  table([["コンサルティング", "3", "￥1,000,000", "￥3,000,000"],
        ["開発", "10", "￥800,000", "￥8,000,000"],
        ["...", "...", "...", "..."]],
        :border_style => :grid, # 全ての行と列に線を引く
        :font_size => 10,
        :headers => ["内容", "数量", "単価", "金額"],
        :widths =>
        { 0 => bounds.width * 0.6,
          1 => bounds.width * 0.1,
          2 => bounds.width * 0.15,
          3 => bounds.width * 0.15},
        :align_headers =>
        { 0 => :center, 1 => :center, 2 => :center, 3 => :center},
        :align =>
        { 0 => :left, 1 => :right, 2 => :right, 3 => :right})

end


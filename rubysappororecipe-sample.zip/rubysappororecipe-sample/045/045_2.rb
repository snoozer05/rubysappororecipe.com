require 'date'
require 'rubygems'
require 'activesupport'

d = Date.today    #=> Mon, 16 Mar 2009
d.to_time         #=> Mon Mar 16 00:00:00 +0900 2009

dt = DateTime.now #=> Mon, 16 Mar 2009 14:03:47 +0900
dt.to_time        #=> Mon, 16 Mar 2009 14:03:47 +0900

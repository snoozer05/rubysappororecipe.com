require 'date'
require 'rubygems'
require 'activesupport'

t = Time.now      #=> Mon Mar 16 14:02:49 +0900 2009
t.to_date         #=> Mon, 16 Mar 2009

dt = DateTime.now #=> Mon, 16 Mar 2009 14:03:47 +0900
dt.to_date        #=> Mon, 16 Mar 2009

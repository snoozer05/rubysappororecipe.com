require 'date'
require 'rubygems'
require 'activesupport'

t = Time.now    #=> Mon Mar 16 14:09:51 +0900 2009
t.to_datetime   #=> Mon, 16 Mar 2009 14:09:51 +0900

dt = Date.today #=> Mon, 16 Mar 2009
dt.to_datetime  #=> Mon, 16 Mar 2009 00:00:00 +0000

require 'rubygems'
require 'temp_dir'

# Dir.mktmpdirメソッドと同様に、ブロックを渡すことで
# 自動的にディレクトリの削除が行なわれる
TempDir.create(:basename => "app") {|dir_path|
  open("#{dir_path}/tmpfile", "w") {|f|
    # 何か処理を行なう
  }
}

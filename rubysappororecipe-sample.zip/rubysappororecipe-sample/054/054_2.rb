require 'tmpdir'

# Dir.mktmpdirメソッドにブロックを渡すと、ブロックから抜ける際に作成した
# 一時ディレクトリを自動的に削除してくれる
Dir.mktmpdir("app") {|dir_path|
  open("#{dir_path}/tmpfile", "w") {|f|
    # 何か処理を行なう
  }
}

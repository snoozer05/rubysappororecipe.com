require 'tmpdir'
require 'fileutils'

dir_path = Dir.mktmpdir("app")
begin
  open("#{dir_path}/tmpfile", "w") {|f|
    # 何か処理を行なう
  }
ensure
  FileUtils.remove_entry_secure dir_path
end

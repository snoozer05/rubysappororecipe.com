require 'rubygems'
require 'temp_dir'
require 'fileutils'

dir_path = TempDir.create(:basename => "app")
begin
  open("#{dir_path}/tmpfile", "w") {|f|
    # 何か処理を行なう
  }
ensure
  FileUtils.remove_entry_secure dir_path
end

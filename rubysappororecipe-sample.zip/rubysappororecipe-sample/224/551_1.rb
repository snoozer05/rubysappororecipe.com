# coding: Shift_JIS

p __ENCDING__  #=> #<Encoding:Shift_JIS>

# coding: UTF-8
methods = Kernel.private_instance_methods

require 'define_lambda_alias'

sym = (Kernel.private_instance_methods - methods)[0]

sym.encoding #=> #<Encoding:UTF-8>

f = λ{ 1 + 2 }
f.call #=> 3
f = __send__('λ'.intern) { 1 + 2 }
f.call #=> 3

# 文字エンコーディングのみが異なる
f =  __send__('λ'.force_encoding('EUC-JP').intern) { 1 + 2 }
     #=> undefined method `λ' for main:Object (NoMethodError)

# バイト列と文字エンコーディングの両方が異なる場合
f =  __send__('λ'.encode('EUC-JP').intern) { 1 + 2 }
     #=> undefined method `??' for main:Object (NoMethodError)

# coding: Shift_JIS
require 'define_lambda_alias'

f = �� { 1 + 2 } #=> undefined method `??' for main:Object (NoMethodError)

f = __send__('��'.encode('UTF-8').intern) { 1 + 2 }
f.call           #=> 3

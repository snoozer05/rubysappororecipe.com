# coding: UTF-8
module Kernel
  alias λ lambda
end

require 'webrick'
include WEBrick

server = HTTPServer.new(:Port => 8000)
server.mount_proc("/"){|req, res|
  HTTPAuth.basic_auth(req, res, "WEBrick's realm") {|user, pass|
    user == 'user' && pass == 'password'
  }
}

trap("INT"){ server.shutdown }
server.start

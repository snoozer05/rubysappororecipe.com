require 'rubygems'
require 'nokogiri'
require 'open-uri'


html = Nokogiri::HTML(open("http://www.google.com/search?q=ruby-sapporo"))

# タグによる検索
html.search('h3.r a.l').each do |tag|
  puts tag
end

# CSSセレクタによる情報の取得
html.css('h3.r a.l').each do |link|
  puts link.content
end

# XPath式による情報の検索
html.xpath('//h3/a[@class="l"]').each do |link|
  puts link.content
end


require 'webrick'
include WEBrick

server = HTTPServer.new(:Port => 10080)

server.mount('/doc', HTTPServlet::FileHandler, File.join(Dir.pwd, "doc"), :FancyIndexing => true)

trap("INT"){ server.shutdown }
server.start


class Team
  def members
    @members ||= [] # 初めて呼ばれたときのみ@membersを初期化
  end

  def add(person)
    members << person
  end

  # ...
end

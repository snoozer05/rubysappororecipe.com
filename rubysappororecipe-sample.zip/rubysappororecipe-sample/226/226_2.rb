"\000\001\002\003\004".each_byte.inject {|a, x| a += x } #=> 10

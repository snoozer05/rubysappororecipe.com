# coding: utf-8
"Ruby 札幌".bytesize #=> 11
"Ruby 札幌".length   #=> 7

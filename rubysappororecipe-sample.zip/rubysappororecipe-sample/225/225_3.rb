# coding: utf-8
s1 = 'kei-s'
s1.encoding    #=> #<Encoding:UTF-8>
s1.ascii_only? #=> true
s2 = '野菜'
s2.encoding    #=> #<Encoding:UTF-8>
s2.ascii_only? #=> false

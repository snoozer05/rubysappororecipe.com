# coding: utf-8
s1 = 'june29'
s1.encoding #=> #<Encoding:UTF-8>
s1.force_encoding('US-ASCII').valid_encoding? #=> true
s2 = '肉'
s2.encoding #=> #<Encoding:UTF-8>
s2.force_encoding('US-ASCII').valid_encoding? #=> false

# coding: utf-8
s = '日本'
s.encoding        #=> #<Encoding:UTF-8>
s.valid_encoding? #=> true

# wget http://svn.coderepos.org/share/platform/tdiary/plugin/jyear.rb
# で取得しておくこと
require 'jyear'

t = Time.now
t.to_s                          #=> "Thu Jul 23 15:11:57 +0900 2009"
t.strftime("%Y-%m-%d")          #=> "2009-07-23"
t.strftime("%Y/%m/%d %H:%M:%S") #=> "2009/07/23 15:11:57"
t.strftime("%K年%m月%d日")      #=> "平成21年07月23日"

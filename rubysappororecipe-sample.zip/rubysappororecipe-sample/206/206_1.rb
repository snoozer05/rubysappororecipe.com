# p.494 Rakefile
task :default => [:hello] # 省略されたときに実行されるタスク

desc "say hello" # ここにタスクの説明を書きます
task :hello do
  sh "echo hello"
end

desc "say goodbye" # ここにタスクの説明を書きます
task :goodbye do
  sh "echo goodbye"
end

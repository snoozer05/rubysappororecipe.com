# p.495 Rakefile
task :default => [:hello]

['hello', 'goodbye'].each do |str|
  desc "say #{str}"
  task str do
    sh "echo #{str}"
  end
end

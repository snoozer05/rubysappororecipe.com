# 特定の期間に含まれる日付かどうか調べる
require 'date'

date = Date.parse("20090611")

start_date = Date.parse("20090101")
end_date = Date.parse("20090131")

(start_date..end_date).include?(date) #=> false

# 特定の期間に含まれる時刻かどうかを調べる
time = Time.local(2009,1,16)

start_time = Time.local(2009,1,1)
end_time = Time.local(2009,1,31)

(start_time..end_time).include?(time) #=> true

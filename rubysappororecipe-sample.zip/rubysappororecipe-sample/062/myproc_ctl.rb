require 'rubygems'
require 'daemons'

Daemons.run_proc('myproc') do
  10.times do |i|
    File.open(File.join(ENV['HOME'], 'myproc.log'), 'a') do |f|
      f.write(i)
    end
    sleep(1)
  end
end

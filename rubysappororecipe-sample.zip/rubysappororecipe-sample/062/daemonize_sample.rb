require 'rubygems'
require 'daemons'

class ConcreteService
  def initialize
    @log_file = File.join(ENV['HOME'], 'myservice.log')
  end

  def logging(content)
    File.open(@log_file, 'a') do |f|
      f.write(content)
    end
  end
end

myservice = ConcreteService.new

Daemons.daemonize # これ以降、このスクリプトはデーモンとして動作する

10.times do |i|
  myservice.logging(i)
  sleep(1)
end

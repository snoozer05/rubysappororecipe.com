#!/usr/bin env ruby

10.times do |i|
  File.open(File.join(ENV['HOME'], 'tmp/myproc.log'), 'a') do |f|
    f.write(i)
  end
  sleep(2)
end

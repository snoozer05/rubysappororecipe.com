require 'rubygems'
require 'daemons'

Daemons.run('mydaemon.rb')

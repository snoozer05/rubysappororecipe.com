require 'test/unit'
require 'rubygems'
require 'mocha'

require 'person'
require 'team'

class TeamTest < Test::Unit::TestCase
  def test_has_admin_should_call_person_admin_once_when_the_team_possesses_only_an_admin_person
    admin = Person.new
    admin.expects(:admin?).once.returns(true)

    team = Team.new
    team.add(admin)

    assert_equal true, team.has_admin?
  end
end


require 'test/unit'
require 'rubygems'
require 'mocha'

require 'person'
require 'team'

class TestTeam < Test::Unit::TestCase
  def test_has_admin_should_return_true_if_team_has_admin
    admin = Person.new
    admin.stubs(:admin?).returns(true)

    team = Team.new
    team.add(admin)

    assert_equal true, team.has_admin?
  end
end

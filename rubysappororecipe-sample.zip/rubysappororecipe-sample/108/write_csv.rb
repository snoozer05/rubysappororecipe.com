require 'csv'

CSV.open('output.csv', 'w') do |writer|
  writer << [1, 'ab, c']
  writer << [2, 'de, f']
end

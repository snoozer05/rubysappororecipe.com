require 'rubygems'
require 'fastercsv'
require 'kconv'

open('ken_all.csv').each do |l|
  row = FasterCSV.parse_line(Kconv::kconv(l, Kconv::UTF8, Kconv::SJIS))
  p row
end

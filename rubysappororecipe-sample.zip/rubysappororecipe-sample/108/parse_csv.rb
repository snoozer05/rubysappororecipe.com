require 'csv'
CSV.foreach('ken_all.csv') do |row|
  p row
end

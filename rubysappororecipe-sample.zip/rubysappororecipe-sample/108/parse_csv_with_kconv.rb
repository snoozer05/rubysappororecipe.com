require 'csv'
require 'kconv'

open('ken_all.csv').each do |l|
  row = CSV.parse_line(Kconv::kconv(l, Kconv::UTF8, Kconv::SJIS))
  p row
end

require 'webrick'
require 'webrick/httputils'
require 'erb'
include WEBrick

#あいさつを返すViewオブジェクト
class Greeting
  Template = <<-EOF
  <html>
    <head><title>Greeting</title></head>
    <body>Hello, <%= @name %></body>
  </html>
EOF
  def self.say(name)
    new(name).hello
  end
  private_class_method :new

  def initialize(name)
    @name = name
  end

  def hello
    ERB.new(Template).result(binding)
  end
end

server = HTTPServer.new(:Port => 10080)

# URIリクエストを元に出力を動的に生成して応答
server.mount_proc("/greeting") do |req, res|
  h = req.header
  p h
  p h["keep-alive"]
  p req["accept"]
  p req.accept
  p req.query
  p req.query["name"]

  res.content_type = "text/html"
  res.body = Greeting.say(HTMLUtils.escape(req.query["name"]))
end

trap("INT"){ server.shutdown }
server.start


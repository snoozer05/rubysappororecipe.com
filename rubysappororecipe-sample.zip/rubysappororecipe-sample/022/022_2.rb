str = "snoozer05"
base64_str = [str].pack('m') #=> "c25vb3plcjA1\n"

str = "\377snoozer05"
[str].pack("m")                #=> "/3Nub296ZXIwNQ==\n"
[str].pack("m").tr('+/', '-_') #=> "_3Nub296ZXIwNQ==\n"
# Base64.encode64メソッドを使った場合も同様
require 'base64'
Base64.encode64(str).tr('+/', '-_') #=> "_3Nub296ZXIwNQ==\n"

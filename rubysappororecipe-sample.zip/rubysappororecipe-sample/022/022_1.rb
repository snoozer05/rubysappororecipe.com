require 'base64'

str = "catch me if you can"
Base64.encode64(str) #=> "Y2F0Y2ggbWUgaWYgeW91IGNhbg==\n"

base64_str = "Y2F0Y2ggbWUgaWYgeW91IGNhbg==\n"
Base64.decode64(base64_str) #=> "catch me if you can"

# 注：これはRuby 1.9用のコードです
require 'base64'

str = "snoozer05"
base64_str = Base64.encode64(str) #=> "c25vb3plcjA1\n"
Base64.decode64(base64_str)       #=> "snoozer05"

str = "\377snoozer05"
Base64.encode64(str)         #=> "/3Nub296ZXIwNQ==\n"

# 以下はRuby 1.9系のBase64モジュールで新たに追加されたメソッド
# RFC 4648に従うBase64エンコード形式とbase64url形式
Base64.strict_encode64(str)  #=> "/3Nub296ZXIwNQ=="
Base64.urlsafe_encode64(str) #=> "_3Nub296ZXIwNQ=="

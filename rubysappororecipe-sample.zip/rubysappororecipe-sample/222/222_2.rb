Encoding.default_internal                        #=> nil
open('somefile', 'r') {|f| f.internal_encoding } #=> nil
open('somefile', 'r:UTF-8') {|f| f.internal_encoding}        #=> nil
open('somefile', 'r:UTF-8:EUC-JP') {|f| f.internal_encoding} #=> #<Encoding:EUC-JP>

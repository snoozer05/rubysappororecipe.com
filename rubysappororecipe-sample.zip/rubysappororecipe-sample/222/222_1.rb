Encoding.default_external                        #=> #<Encoding:US-ASCII>
open('somefile', 'r') {|f| f.external_encoding } #=> #<Encoding:US-ASCII>
open('somefile', 'r:UTF-8') {|f| f.external_encoding } #=> #<Encoding:UTF-8>

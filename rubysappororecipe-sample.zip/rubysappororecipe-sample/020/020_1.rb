require 'kconv'

str = "何かの文字エンコーディングで符号化された文字列"
euc_jp_str = str.toeuc  # strの文字エンコーディングを自動判別してEUC-JPに変換
sjis_str = str.tosjis   # Shift_JISに変換
jis_str = str.tojis     # JIS（ISO-2022-JP）に変換
utf8_str = str.toutf8   # BOM無しUTF-8に変換
utf16_str = str.toutf16 # BOM無しUTF-16BEに変換

euc_jp_str = str.kconv(Kconv::EUC, Kconv::SJIS) # Shift_JISからEUC-JPへ変換

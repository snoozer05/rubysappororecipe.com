require 'iconv'

euc_jp_str = "EUC-JP�ǽ񤫤줿ʸ��"
utf8_str = Iconv.conv('UTF-8', 'EUC-JP', euc_jp_str)

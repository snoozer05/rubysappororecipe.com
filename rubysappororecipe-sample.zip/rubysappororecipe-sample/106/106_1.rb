require 'yaml'
# YAML形式でデータを書き出す
## オブジェクトをYAML形式の文字列に変換
config = {:port => "3000", :url => "example.com"}
config.to_yaml #=> "--- \n:port: 3000\n:url: example.com\n"

## オブジェクトをYAML形式に変換してIOに書き出す
open("config.yml", "w") do |f|
  YAML.dump(config, f)
end

require 'yaml'
# YAML形式のデータを読み戻す
## YAML形式のファイルを読み込んでオブジェクトを復元する
config = YAML.load_file("config.yml") #=> {:port => "3000", :url => "example.com"}

## YAML形式の文字列からオブジェクトを復元する
original_config = {:port => "3000", :url => "example.com"}
config = YAML.load(original_config.to_yaml)

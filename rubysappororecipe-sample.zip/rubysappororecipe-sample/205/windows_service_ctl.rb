require 'rubygems'
require 'win32/service'
require 'optparse'
include Win32

ARGV.options do |opts|
  opts.on('-s', '--start SERVICE', String, '�T�[�r�X�̊J�n') do |service_name|
    Service.start(service_name)
    loop do
      s = Service.status(service_name)
      break if s.current_state == "running"
      puts "One moment, " + s.current_state
      sleep 1
    end
    puts "#{service_name} service started"
  end

  opts.on('-x', '--stop SERVICE', String, '�T�[�r�X�̒�~') do |service_name|
    Service.stop(service_name)
    loop do
      s = Service.status(service_name)
      break if s.current_state == "stopped"
      puts "One moment, " + s.current_state
      sleep 1
    end
    puts "#{service_name} service stopped"
  end

  begin
    opts.parse!
  rescue OptionParser::ParseError => err
    $stderr.puts err.message
    exit 1
  end
end

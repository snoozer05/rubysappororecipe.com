require 'rubygems'
require 'mechanize'

UPLOAD_URL  = "http://rubyrecipe.ruby-sapporo.org/multipart_post/index.html"
UPLOAD_FILE = "attach.zip"

agent = WWW::Mechanize.new
# まずフォームを取得し
page = agent.get(URI.parse(UPLOAD_URL))

# フォームを埋めて
page.forms[0].username = "snoozer05"
page.forms[0].file_upload_with(:name => "upload_file").file_name = UPLOAD_FILE

# submit(ファイルのアップロード)
result_page = agent.submit(page.forms[0])
puts result_page.content


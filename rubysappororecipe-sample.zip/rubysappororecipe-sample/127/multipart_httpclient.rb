require 'rubygems'
require 'httpclient'

boundary = "-----------------rubyrecipe"
c = HTTPClient.new
File.open("attach.zip", "rb") do |f|
  postdata = { "username" => "snoozer05", "upload_file" => f } # (1)
  puts c.post_content("http://rubyrecipe.ruby-sapporo.org/multipart_post/post.cgi",
                      postdata,
                      "content-type" => "multipart/form-data, boundary=#{boundary}")
end

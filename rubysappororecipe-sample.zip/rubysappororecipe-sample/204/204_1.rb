# p.487
RAILS_ROOT = "/home/webapps/testapp"

(3000..3002).each do |port|
  God.watch do |w|
    w.name = "thin-#{port}"
    w.group = "thin"
    w.pid_file = "#{RAILS_ROOT}/tmp/pids/thin.#{port}.pid"
    w.start = "thin start -c #{RAILS_ROOT} -d -p #{port} -e production -P #{w.pid_file}"
    w.restart = "thin restart -P #{w.pid_file}"
    w.stop = "thin stop -P #{w.pid_file}"
    w.behavior(:clean_pid_file)
    w.start_if do |start|
      start.condition(:process_running) do |c|
        c.running = false
        c.interval = 5.seconds
      end
    end
    # 以下の設定を追加することで、メモリの利用量や占有率が指定値を超えた
    # 場合に再起動できる
    w.transition(:up, :restart) do |on|
      on.condition(:memory_usage) do |c|
        c.interval = 20
        c.above = 50.megabytes
        c.times = [3, 5]
      end

      on.condition(:cpu_usage) do |c|
        c.interval = 10
        c.above = 10.percent
        c.times = [3, 5]
      end
    end
  end
end

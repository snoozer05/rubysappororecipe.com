require 'singleton'

class Factory
  include Singleton

  # ...
end

factory = Factory.instance #=> #<Factory:0x1e190>
factory = Factory.new      #=> NoMethodError

factory = Factory.instance
factory.dup                #=> TypeError
factory.clone              #=> TypeError

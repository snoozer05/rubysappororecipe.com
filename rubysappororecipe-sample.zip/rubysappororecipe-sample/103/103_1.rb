# 値の保存と取得（p.225）
require 'rubygems'
require 'memcache'

options = {:namespace => 'my_namespace'}
CACHE = MemCache.new('localhost:11211', options)

CACHE.set("key1", "value1", 60) # "key1" に "value1" を結び付けて保存
puts CACHE.get("key1")          # "key1" をキーにして値（"value1"）を取り出し


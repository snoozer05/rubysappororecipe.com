# 再利用したいけれどメソッドの名前が適切ではない
class Moji
  def color(color)
    # ...
  end

  def hutosa
    # ...
  end

  def kage
    # ...
  end

  def angle
    # ...
  end
end

# DelegateClassを使用して既存のクラスを変更することなく仕様を変更する
require 'delegate'

class Text < DelegateClass(Moji)
  def initialize
    super(Moji.new)
  end

  # メソッド名を変更しつつ、引数の追加や機能の拡張を行なう
  def size(size)
    # ...
    hutosa # オリジナルのメソッドを呼び出す
    # ...
  end

  # 推奨されないメソッドに対して警告を出す
  def angle
    puts "warning: obsolete method"
    super
  end

  # メソッド名を変更する
  alias_method :shadow, :kage
end

# 変換したインターフェイスを利用する
text = Text.new

text.color(Color::RED)
text.shadow
text.size(10)
text.angle

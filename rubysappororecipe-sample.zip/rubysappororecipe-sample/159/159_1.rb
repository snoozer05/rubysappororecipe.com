require 'dl/import'

module LIBC
  extend DL::Importable
  dlload "libc.dylib", "libm.dylib"  # Mac OS X の場合
  extern "double atan2(double, double)"
end

LIBC.atan2(0.0, -1.0)   #=> 3.14159265358979

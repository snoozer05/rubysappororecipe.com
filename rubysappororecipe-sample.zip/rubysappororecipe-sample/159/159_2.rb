require 'dl/import'
require 'dl/struct'

module LIBC
  extend DL::Importable
  dlload "libc.dylib"  # Mac OS X の場合
  extern "int gettimeofday(timeval*, timezone*)"
  Timeval = struct [
    "long tv_sec",
    "long tv_usec",
  ]
  Timezone = struct [
    "int tz_minuteswest",
    "int tz_dsttime"
  ]
end

tv = LIBC::Timeval.malloc
tz = LIBC::Timezone.malloc
LIBC.gettimeofday(tv, tz)          #=> 0
[tv.tv_sec, tv.tv_usec]            #=> [1232015743, 152908]
[tz.tz_minuteswest, tz.tz_dsttime] #=> [-540, 0]

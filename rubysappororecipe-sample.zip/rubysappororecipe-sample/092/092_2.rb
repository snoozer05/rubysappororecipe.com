# alias_methodを使ってメソッドを拡張する
class Foo
  def process
    puts "do_something"
  end
end

# Fooクラスを再定義する際、alias_methodメソッドを使うことで、
# メソッドの名前を変えずに機能のみを追加できる
class Foo
  alias_method :old_process, :process
  def process
    puts "do_something_more"
    old_process
  end
end

class Numeric
  # ポンド
  def pound
    self * 453.59237
  end

  # 記号表記（lb）でもポンドを扱えるようにする
  alias_method :lb, :pound
end


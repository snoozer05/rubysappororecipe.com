class MyLazyList
  def initialize(&block)
    unless block
      raise ArgumentError, 'tried to create Proc object without a block'
    end
    @block = block
    @ary = []
  end

  def [](index)
    @ary[index] ||= @block.call(index)
    @ary[index]
  end
end

def MyLazyList(&block)
  MyLazyList.new(&block)
end

fib = MyLazyList {|i| (i == 0 || i == 1) ? 1 : fib[i-1] + fib[i-2] }
fib[500] # => 225591516161936330872512695036072072046011324913758190588638866418474627738686883405015987052796968498626

require 'rubygems'
require 'tmail'
require 'kconv'

raw_mail = File.open('simple_mail.txt', "rb"){ |f| f.read}

email = TMail::Mail.parse(raw_mail)

# 結果の表示
puts email.from.join(", ")
puts email.to.join(", ")
puts email.cc.join(", ")
puts email.content_type
puts email.subject.toutf8
puts email.body('EUC-JP')




class DecoderFactory
  def self.create(file_type)
    case file_type
    when :mp3
      MyMp3Decoder.new
    when :aac
      MyAacDecoder.new
    when :atrac3
      # MyMp3DecoderやMyAacDecoderとは継承関係にないサードパーティが提供しているデコーダー
      ThirdPartyAtrac3Decoder.new
    end
  end
end

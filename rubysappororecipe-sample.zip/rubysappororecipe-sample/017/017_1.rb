nick = "snoozer05"
message = "#{nick}さん、こんにちは" #=> "snoozer05さん、こんにちは"

calc = "1+3は#{1+3}です" #=> "1+3は4です"

task :byebye do
  sh "echo goodbye!"
end

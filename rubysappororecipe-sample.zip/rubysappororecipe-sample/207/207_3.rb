task :lsreadme do
  sh 'ls readme' do |ok, res|
    unless ok
      puts "Error (%d)" % res.exitstatus
    end
  end
end

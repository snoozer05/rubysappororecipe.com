task :byebye do
  sh "echo", "good bye", "!"
end

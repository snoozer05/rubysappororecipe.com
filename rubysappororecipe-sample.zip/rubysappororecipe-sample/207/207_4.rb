# p.497
task :myscript do
  ruby "myscript.rb"
end

# localhost上にあるPostgreSQLのar_exampleというDBに接続する例
require 'rubygems'
require 'activerecord'

ActiveRecord::Base.establish_connection(
  :adapter  => 'postgresql',
  :host     => 'localhost',
  :database => 'ar_example',
  :username => 'username',
  :password => 'password',
  :encoding => 'UTF-8'
)

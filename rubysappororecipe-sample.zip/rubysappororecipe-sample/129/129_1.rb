require 'rubygems'
require 'pit'

# ユーザー名をuser, パスワードをpassでruby-sapporoという
# アカウント情報を取得する
Pit.set("ruby-sapporo", :data => {
          "username" => "user",
          "password" => "pass"
})

config =  Pit.get("ruby-sapporo")

require 'drb'

class DB
  def initialize
    @hash = { }
  end

  def put(key, value)
    @hash[key] = value
  end

  def get(key)
    @hash[key]
  end
end

DRb.start_service("druby://:12345", DB.new)
puts DRb.uri
sleep


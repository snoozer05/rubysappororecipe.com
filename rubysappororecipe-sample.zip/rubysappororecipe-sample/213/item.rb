# Itemの基底クラス
class Item
  # 原点右下で横方向の位置
  attr_accessor :x
  # 原点右下で縦方向の位置
  attr_accessor :y
  # 幅
  attr_accessor :width
  # 高さ
  attr_accessor :height
  def initialize
    @children = []
  end

  # 自身を描画
  def show
  end

  # === 概要
  # 自身に他のitemを内包させます。
  # Item#remove_child も参照。
  #
  # === 引数
  # +item+:: itemオブジェクト
  #
  # === 戻り値
  # 内包するchildのArrayを返します
  #
  # === 例外
  # +ArgumentError+:: +item+のサイズが自身より大きい場合
  #
  def add_child(item)
    if item.width > self.width || item.height > self.height
      raise ArgumentError.new
    end
    @children << item
  end

  def remove_child(item) # 子アイテムを削除
    return @children.delete(item)
  end
end

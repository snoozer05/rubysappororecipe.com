class Text < Item
  attr_accessor :value, :font, :color

  def initialize
  end
end

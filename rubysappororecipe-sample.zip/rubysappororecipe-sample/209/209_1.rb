# p.500 Rakefile
task :default => ['greeting:hello']

namespace :greeting do
  ['hello', 'goodbye'].each do |str|
    desc "say #{str}"
    task str do
      sh "echo #{str}"
    end
  end
end

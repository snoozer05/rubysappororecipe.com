# p.501 Rakefile
namespace :greeting do
  namespace :en do
    desc "say hello in English"
    task :hello do
      sh "echo hello"
    end
  end
  namespace :ja do
    desc "say hello in Japanese"
    task :hello do
      sh "echo konichiwa"
    end
  end
end

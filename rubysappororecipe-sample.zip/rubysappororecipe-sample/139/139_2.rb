require 'rubygems'
require 'icalendar'
require 'date'

cal = Icalendar::Calendar.new

event = Icalendar::Event.new
event.dtstart = Date.new(2008, 11, 6)
event.dtend = Date.new(2008, 11, 7)
event.summary = "Ruby逆引きレシピ打ち合わせ"
event.klass = "PRIVATE"

cal.add_event(event)

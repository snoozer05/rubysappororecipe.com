require 'rubygems'
require 'icalendar'

File.open("single_event.ics") do |f|
  cal = Icalendar.parse(f).first
  event = cal.events.first

  puts event.dtstart
  puts event.summary
end

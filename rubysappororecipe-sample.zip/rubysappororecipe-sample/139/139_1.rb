require 'rubygems'
require 'icalendar'
require 'date'

cal = Icalendar::Calendar.new

cal.event do
  dtstart     Date.new(2008, 11, 6)
  dtend       Date.new(2008, 11, 7)
  summary     "Ruby逆引きレシピ打ち合わせ"
  description "執筆状況の確認を行う"
  klass       "PRIVATE"
end

cal.to_ical

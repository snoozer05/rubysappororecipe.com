require 'rubygems'
require 'rack'

class HelloWorld
  def call(env)
    req = Rack::Request.new(env)
    name = Rack::Utils.escape_html(req.params['name'])
    Rack::Response.new("Hello, #{name}!", 200).finish
  end
end


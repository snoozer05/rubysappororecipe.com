require 'rubygems'
require 'rack'

class HelloWorld
  def call(env)
    Rack::Response.new("Hello, world.", 200).finish
  end
end


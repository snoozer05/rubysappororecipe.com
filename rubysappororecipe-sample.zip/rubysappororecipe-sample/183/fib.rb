def fibonacci(i)
  (i == 0 || i == 1) ? 1 : fibonacci(i - 1) + fibonacci(i - 2)
end
n = 20
puts "fib(%d) = %d" % [n, fibonacci(n)]

require 'rubygems'
require 'activesupport'

Time.days_in_month(11) #=> 30

Time.days_in_month(2,2008) #=> 29
Time.days_in_month(2,2009) #=> 28

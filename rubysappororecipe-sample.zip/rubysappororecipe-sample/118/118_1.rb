require 'webrick'
include WEBrick

server = HTTPServer.new(:Port => 10080)

# 'http://localhost:10080/there'にアクセスされたら'http://example.com'にリダイレクト
server.mount_proc('/there') do |req, res|
  res.set_redirect(HTTPStatus::SeeOther, 'http://example.com')
end

trap("INT") { server.shutdown }
server.start

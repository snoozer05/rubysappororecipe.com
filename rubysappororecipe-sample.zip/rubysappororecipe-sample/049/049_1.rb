File.basename('/Users/muraken/work/ruby-sapporo') #=> "ruby-sapporo"
File.dirname('/Users/muraken/work/ruby-sapporo')  #=> "/Users/muraken/work"
File.split('/Users/muraken/work/ruby-sapporo')    #=> ["/Users/muraken/work", "ruby-sapporo"]

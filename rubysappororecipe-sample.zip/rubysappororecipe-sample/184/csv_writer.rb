class CsvWriter
  def write_line(fields)
    if (fields.length == 0)
      puts
    else
      write_field(fields[0])
      1.upto(fields.length-1) do |i|
        print ","
        write_field(fields[i])
      end
      puts
    end
  end
end

require 'date'
require 'fileutils'

# logディレクトリに移動しログファイルをバックアップ
Dir.chdir('log') do
  backup_dir = (Date.today - 1).strftime('%y%m%d')
  FileUtils.mkdir(backup_dir) unless File.directory?(backup_dir)
  FileUtils.cp(Dir['*.log'], backup_dir)
end

require 'rubygems'
require 'gruff'

g = Gruff::StackedBar.new(640) # 生成される画像の横幅を640pxに設定
g.title = 'Visitors'
g.data 'Returning', [397, 698, 462, 363, 313, 329, 477, 379, 214, 381, 189, 117]
g.data 'New', [405, 727, 390, 384, 346, 558, 797, 353, 283, 640, 294, 298]
g.labels = {0=>'Jan', 1=>'Feb', 2=>'Mar', 3=>'Apr', 4=>'May', 5=>'Jun',
            6=>'Jul', 7=>'Aug', 8=>'Sep', 9=>'Oct', 10=>'Nov', 11=>'Dec'}
g.minimum_value = 0
g.write('stacked_bar.png')

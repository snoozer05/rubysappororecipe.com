require 'rubygems'
require 'gruff'

g = Gruff::Pie.new(640) # 生成される画像の横幅を640pxに設定
g.title = 'Visitors'
g.data 'Returning', 4319
g.data 'New', 5475
g.zero_degree = -90
g.write('pie.png')

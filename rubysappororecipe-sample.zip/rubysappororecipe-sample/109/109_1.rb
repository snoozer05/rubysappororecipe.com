require 'rubygems'
require 'net/irc'

class ExampleClient < Net::IRC::Client
  def on_rpl_welcome(m)
    post JOIN, opts.channel
  end
  def on_privmsg(m)
    channel, message = *m
    post NOTICE, channel, "%s, %s!" % [m.prefix.nick, message]
  end
end
client = ExampleClient.new("irc.freenode.net", 6667,
  {:nick => "rrbot", :user => "rrbot", :real => "rrbot",
    :channel => "#rrexample"}
)
client.start


require 'erb'
erb = ERB.new('Hello, <%= name %>')

name = "World"
puts erb.result(binding)

name = "Rubyists"
puts erb.result(binding)

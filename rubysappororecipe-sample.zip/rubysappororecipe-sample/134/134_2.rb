require 'erb'
template = <<-EOT
<% for i in 1..5 %>
  <%= i %>: <% if (i % 2) == 0 %>
    偶数
  <% else %>
    奇数
  <% end %>
<% end %>
EOT
erb = ERB.new(template)
print erb.result

require 'rubygems'
require 'tmail'
require 'kconv'

mail=TMail::Mail.parse($stdin.read)
if mail.multipart?
  p mail.parts
  mail.parts.each_with_index do |part, idx|
    fname =  part.disposition_param('filename')
    if fname.nil?
      fname = "#{idx.to_s}.#{part.content_type.gsub(/\//, "_")}"
    else
      fname = fname.toutf8
    end

    File.open(fname, 'wb') do |f|
      f.write part.body
    end
  end
end

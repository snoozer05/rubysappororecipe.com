require 'net/http'

Net::HTTP.version_1_2   # おまじない
url = URI.parse('http://ruby:rubyrecipe@rubyrecipe.ruby-sapporo.org/net-http/post.cgi')
res = Net::HTTP.post_form(url, {'name' => 'tmaeda'})
if res.class == Net::HTTPOK
  puts res.body
else
  puts "#{res.code}: #{res.message}"
end

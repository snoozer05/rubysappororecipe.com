require 'forwardable'

class ProcessProxy
  extend Forwardable

  def_delegators :@process_executer, :command1, :command2

  def initialize
    @process_executer = ProcessExecuter.new
  end

  # ...
end

require 'forwardable'

class ProcessProxy
  extend Forwardable

  def_delgator :@process_executer, :execute, :proxy_execute

  def initialize
    @process_executer = ProcessExecuter.new
  end

  # ...
end


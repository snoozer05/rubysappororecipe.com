# 外部から参照も変更も行ないたい場合には、
# attr_accessorメソッドを使う
class Book
  attr_accessor :owner
  attr_reader :title, :author

  def initialize(title, author, owner=:mine)
    @title, @author, @owner = title, author, owner
  end
end

book = Book.new("Ruby逆引きレシピ", "Ruby札幌")
book.owner           #=> :mine
book.owner = :sister
book.owner           #=> :sister

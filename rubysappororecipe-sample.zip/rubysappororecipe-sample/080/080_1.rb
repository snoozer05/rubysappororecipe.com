# インスタンス変数の内容を外部から変更可能にするには、
# attr_writerメソッドを使う
class Book
  attr_writer :owner
  attr_reader :title, :author

  def initialize(title, author, owner=:mine)
    @title, @author, @owner = title, author, owner
  end
end

book = Book.new("Ruby逆引きレシピ", "Ruby札幌")
book.owner = :sister #=> :sister

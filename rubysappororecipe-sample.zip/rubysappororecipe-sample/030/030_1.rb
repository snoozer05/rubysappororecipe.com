require 'rubygems'
require 'narray'

NArray.int(10)   # => NArray.int(10): [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 ]
NArray.object(4) # => NArray.object(4): [ nil, nil, nil, nil ]

NArray.int(5).indgen!(10, 10) #=> NArray.int(5): [ 10, 20, 30, 40, 50 ]
NArray.float(5).randomn!      #=> NArray(ref).float(5): [ 0.961481, -0.159616, -0.0427719, -1.14735, -0.446647 ]

NArray[1, 2, 3]     #=> NArray.int(3): [ 1, 2, 3 ]
NArray[1.0, 2, 3]   #=> NArray.float(3): [ 1.0, 2.0, 3.0 ]
NArray[true, false] #=> TypeError: can't convert true into Integer

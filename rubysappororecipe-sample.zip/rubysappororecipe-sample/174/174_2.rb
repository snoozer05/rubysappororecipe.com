require 'syslog'

Syslog.open("blog", Syslog::LOG_NDELY | Syslog::LOG_PERROR) do |syslog|
  syslog.warning("disk full")
end


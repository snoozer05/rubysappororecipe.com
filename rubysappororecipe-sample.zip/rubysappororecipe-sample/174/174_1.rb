require 'syslog'

Syslog.open("blog") do |syslog|
  syslog.warning("disk full")
end


require 'test/unit'
require 'user'

class TestUser < Test::Unit::TestCase
  def setup
    @user = User.new(:name => "SHIMADA Koji", :age => 30)
    @user.save
  end

  def teardown
    @user.destroy
  end

  def test_signup_by_nonuser
    # ...
  end

  def test_signup_by_user
    # ...
  end
end


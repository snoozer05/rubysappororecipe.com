require 'test/unit'
require 'rubygems'
require 'shoulda'
require 'user'

class UserTest < Test::Unit::TestCase
  def setup
    # テストメソッドごとに実行される処理
  end

  # Userのインスタンスが存在するとき
  context "A User instance" do
    setup do
      @user = User.find(:first)
    end

    # 名前が「SHIMADA Koji」であるべき
    should "return its full name" do
      assert_equal 'SHIMADA Koji', @user.name
    end

    # UserインスタンスがProfileを持つとき
    context "with a profile" do
      setup do
        @user.profile = Profile.find(:first)
      end

      should "return true, receiving #has_profile?" do
        assert @user.has_profile?
      end
    end
  end
end

# COLUMN クラスやモジュールを凍結するとどうなるか(p.171)

# Eventクラスを定義
class Event
  # ...
end

# Eventクラスの凍結
Event.freeze
Event.frozen? # => true

# Eventクラスに新しいメソッドを追加するとTypeError
class Event
  def timestamp
    # ...
  end
end

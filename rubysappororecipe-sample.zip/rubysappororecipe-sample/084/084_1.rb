# Object#freezeメソッドでオブジェクトに関する変更を禁止できる
values = [1, 2, 3] #=> [1, 2, 3]
values << 4        #=> [1, 2, 3, 4]
values.freeze      #=> [1, 2, 3, 4]
values << 5        #=> TypeError: can't modify frozen array

# オブジェクトが凍結されているかどうかはObject#frozen?メソッドで確認できる
values = [1, 2, 3] #=> [1, 2, 3]
values.frozen?     #=> false
values.freeze      #=> [1, 2, 3]
values.frozen?     #=> true

# 再び変更したくなった場合には、Object#dupメソッドを使って
# オブジェクトをコピーする
base_values = [1, 2, 3]       #=> [1, 2, 3]
base_values.freeze            #=> [1, 2, 3]
base_values.frozen?           #=> true
copy_values = base_values.dup #=> [1, 2, 3]
copy_values.frozen?           #=> false
copy_values << 4              #=> [1, 2, 3, 4]

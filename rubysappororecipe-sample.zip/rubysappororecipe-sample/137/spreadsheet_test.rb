require 'rubygems'
require 'spreadsheet'

# Excelファイルを開く
book = Spreadsheet.open('estimate.xls')

# 1つめのシートへの参照を取得
sheet = book.worksheet(0)

# 宛先
sheet[4,0] = "(株)レシピ出版"
# 日付
sheet[3,4] = Time.now
# 品名
sheet[14,0] = "コンサルティング"
# 単価
sheet[14,2] = 1200000
# 数量
sheet[14,3] = 2

# 別名保存
book.write('test.xls')

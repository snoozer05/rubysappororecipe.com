require 'webrick'
include WEBrick

server = HTTPServer.new(:Port => 8000)

server.mount_proc("/"){|req, res|
  res.set_error(HTTPStatus::BadRequest.new("リクエスト不正"))
}

trap("INT"){ server.shutdown }
server.start


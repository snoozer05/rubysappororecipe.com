require 'webrick'
include WEBrick

server = HTTPServer.new(:Port => 8000)

server.mount_proc("/"){|req, res|
  res.status = 404
}

trap("INT"){ server.shutdown }
server.start


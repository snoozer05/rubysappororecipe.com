require 'test/unit'
require 'user'

class TestUser < Test::Unit::TestCase
  # 非会員である利用者が会員登録した場合
  def test_signup_by_nonuser
    # ここに検証内容を書いていく
  end

  # 会員となっている利用者が2重で会員登録を行おうとした場合
  def test_signup_by_user
    # ここに検証内容を書いていく
  end
end



require 'rubygems'
require 'RedCloth'

# Textile記法で書かれたテキスト
text = <<EOP
h1. Textile記法のサンプル

ここは本文になります。

h2. リスト

# 箇条書きレベル1
## 箇条書きレベル2

h2. 引用

bq. ここは引用になります。

h2. リンク

# "Ruby札幌":http://ruby-sapporo.org
EOP

# Textile記法で書かれたテキストからHTMLを生成
parser = RedCloth.new(text)
puts parser.to_html

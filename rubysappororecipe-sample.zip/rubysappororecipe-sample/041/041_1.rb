require 'date'

d = Date.parse("S53.11.6")
d.strftime("%Y-%m-%d") #=> "1978-11-06"

d = Date.parse("S53-11-6")
# 和暦としてパースできない
d.strftime("%Y-%m-%d") #=> "0053-11-06"

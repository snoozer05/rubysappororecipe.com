# JSON形式でデータを書き出す
require 'rubygems'
require 'json'

data = {"name" => "dara", "admin" => true, "age" => 29,
        "mail" => ["mail@example.jp", "mail@example.com"]}
puts JSON.dump(data)

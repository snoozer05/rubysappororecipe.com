# JSON形式のデータを読み戻す
require 'rubygems'
require 'json'

str = '{"name":"dara","admin":true,"mail":["mail@example.jp","mail@example.com"],"age":29}'
user = JSON.load(str)
p user

user["name"] #=> "dara"

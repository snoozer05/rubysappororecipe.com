require 'rubygems'
require 'httparty'

class Twitter
  include HTTParty
  base_uri 'twitter.com'
  def initialize(username, password)
    @auth = {:username => username, :password => password }
  end

  def update(str)
    self.class.post('/statuses/update.json',
                    :query => { :status => str}, :basic_auth => @auth)
  end
end

twitter = Twitter.new('username', 'password') # ユーザー名とパスワードを指定
twitter.update("Hello, world.")




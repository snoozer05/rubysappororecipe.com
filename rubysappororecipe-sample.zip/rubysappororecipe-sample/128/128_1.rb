require 'rubygems'
require 'httparty'

class Twitter
  include HTTParty
  base_uri 'twitter.com'
  basic_auth 'username', 'password' # ユーザー名とパスワードを指定
end

p Twitter.post("/statuses/update.json", :query => { :status => "Hello, world."})


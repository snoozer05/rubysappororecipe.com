require 'rubygems'
require 'httparty'

class Twitter
  include HTTParty
  base_uri 'twitter.com'
  basic_auth 'username', 'password'

  format :xml
end

p Twitter.post("/statuses/update.xml", :query => { :status => "Hello, world."})


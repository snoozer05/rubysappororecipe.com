require 'rubygems'
require 'sinatra'

get '/ja' do
  'こんにちは！'
end

get '/' do
  "Hello world!"
end


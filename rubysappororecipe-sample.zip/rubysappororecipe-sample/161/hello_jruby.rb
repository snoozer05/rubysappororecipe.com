require 'java'
import 'java.lang.System'

System.out.println("Hello, JRuby")

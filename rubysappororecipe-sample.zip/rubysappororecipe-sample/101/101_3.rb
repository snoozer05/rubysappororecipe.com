# トランザクションの利用
begin
  db.query("begin")
  db.query("insert into blogs ...")
  db.query("insert into entries ...")
  db.commit
rescue
  db.rollback
ensure
  db.close
end

# プレースホルダとバインド変数の利用
## プレースホルダとバインド変数を使用してSQLを発行
sql = "select * from users where id=? and name=? and created_at < ?"
stmt = db.prepare(sql)
stmt.execute(1, '松本', Time.now)
stmt.each{|r| puts r}
stmt.close

## 結果を1件だけ取得するには、Mysql::Stmt#fetchメソッドを使う
# sql = "..."
# stmt = db.prepare(sql)
i = 0
while i < stmt.num_rows do
  puts stmt.fetch
  i += 1
end
# stmt.close

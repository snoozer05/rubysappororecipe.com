# 基本的な操作
require 'rubygems'
require 'mysql'

db = Mysql.connect('127.0.0.1', 'my_name', 'my_password', nil, 3306)

begin
  db.query("create database example default character set utf8")
  db.query("use example")
  db.query("create table users (id int, name varchar(32), created_at datetime)")
  db.query("insert into users values (1, '松本', '2009-01-01 12:34:56')")
  db.query("select * from users") do |res|
    res.each_hash do |hash|
      hash.each {|k,v| puts "#{k}=#{v}"}
    end
  end
ensure
  db.close
end

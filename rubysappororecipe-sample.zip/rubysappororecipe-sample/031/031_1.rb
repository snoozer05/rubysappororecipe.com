require 'rubygems'
require 'narray'

b = NVector[3.0, 10.0]
a = NMatrix[ [1.0, 1.0],
             [4.0, 3.0] ]
x = b / a
p x

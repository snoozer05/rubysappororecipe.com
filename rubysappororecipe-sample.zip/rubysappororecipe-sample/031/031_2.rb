require 'rubygems'
require 'narray'

b1 = NVector[3.0, 10.0]
b2 = NVector[5.0, 16.0]

a = NMatrix[ [1.0, 1.0],
             [4.0, 3.0] ]

a_lu = a.lu # LU 分解の結果を保存し、以下で再利用
p a_lu.solve(b1)
p a_lu.solve(b2)

# オブジェクトコピー時に生成時間を初期化する
class Record
  # オブジェクト生成時に実行される初期化メソッド
  def initialize(content)
    @content = content
    timestamp
  end

  # オブジェクトのコピー時に実行される初期化メソッド
  def initialize_copy(obj)
    timestamp
  end

  def timestamp
    @created_at = Time.now
  end

  attr_accessor :content
  attr_reader :created_at
end

# コピー元のオブジェクトを用意
original = Record.new("ruby-sapporo")
original.created_at #=> Thu Jul 23 18:24:58 +0900 2009

sleep(1)

# オブジェクトをコピーするとコピー時のタイムスタンプで初期化
clone = original.clone
clone.created_at    #=> Thu Jul 23 18:24:59 +0900 2009

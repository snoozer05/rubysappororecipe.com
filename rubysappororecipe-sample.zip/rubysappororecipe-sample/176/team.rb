class Team
  def initialize
    @members = []
  end

  def add(member)
    @members << member
  end

  def has_admin?
    @members.any?{|m| m.admin?}
  end
end

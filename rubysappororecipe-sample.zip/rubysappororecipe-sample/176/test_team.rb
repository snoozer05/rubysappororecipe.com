require 'test/unit'
require 'team'
require 'person'

class TeamTest < Test::Unit::TestCase
  def test_has_admin_should_return_true_if_team_has_admin
    team = Team.new
    team.add(Person.admin)

    # team.has_admin?の結果がtureであることを検証
    assert_equal true, team.has_admin?
  end
end

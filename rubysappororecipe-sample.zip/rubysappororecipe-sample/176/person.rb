class Person
  def self.admin
    Person.new(:admin => true)
  end

  def initialize(attrs)
    @admin = attrs[:admin]
  end

  def admin?
    @admin
  end
end

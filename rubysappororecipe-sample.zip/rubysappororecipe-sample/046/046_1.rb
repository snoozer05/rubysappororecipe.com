t = Time.now
t.to_s                          #=> "Mon Mar 02 15:28:08 +0900 2009"
t.strftime("%Y-%m-%d")          #=> "2009-03-02"
t.strftime("%Y/%m/%d %H:%M:%S") #=> "2009/03/02 15:03:08"

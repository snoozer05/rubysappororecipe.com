require 'time'

t = Time.now
t.rfc822    #=> "Mon, 02 Mar 2009 15:28:08 +0900"
t.httpdate  #=> "Mon, 02 Mar 2009 06:28:08 GMT"
t.xmlschema #=> "2009-03-02T15:28:08+09:00"

class Command
  def self.run
    #...
  end
end

if __FILE__ == $0
  Command.run
end

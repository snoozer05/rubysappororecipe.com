# coding: UTF-8
ec = Encoding::Converter.new("UTF-8", "EUC-JP")
src = "日本\x81Ruby\u{20bb7}の会\xe3"
dst = ''
while true
  ret = ec.primitive_convert(src, dst)
  case ret
  when :invalid_byte_sequence
    # 不正なバイト列へ対応する
    # ここでは不正なバイト列を [invalid_byte_sequence] で置き換える
    ec.insert_output('[invalid_byte_sequence]')
  when :undefined_conversion
    # 未定義文字へ対応する
    # ここでは未定義文字を [undefined] で置き換える
    ec.insert_output('[undefined]')
  when :incomplete_input
    # 不完全なバイト列の入力へ対応する
    # ここでは不完全なバイト列を [incomplete] で置き換える
    ec.insert_output('[incomplete]')
  when :finished
    break
  end
end
print dst.dump
#=> "\xC6\xFC\xCB\xDC[invalid_byte_sequence]Ruby[undefined]\xA4\xCE\xB2\xF1[incomplete]"

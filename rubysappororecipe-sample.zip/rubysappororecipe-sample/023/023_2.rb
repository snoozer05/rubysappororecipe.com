require 'MeCab' # mecab や Mecab ではないことに注意
$KCODE='u'

mecab = MeCab::Tagger.new
node = mecab.parseToNode("となりの客はとく柿食う客だ")
freqs = Hash.new(0)
begin
  f = node.feature.split(/,/)
  freqs[node.surface] += 1 if %w(名詞 動詞).include?(f[0])
end while(node = node.next)

p freqs

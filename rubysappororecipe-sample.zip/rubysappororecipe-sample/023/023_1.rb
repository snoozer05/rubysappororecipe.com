require 'MeCab' # mecab や Mecab ではないことに注意
$KCODE='u'

m = MeCab::Tagger.new("-Owakati")
p m.parse("隣の客はよく柿食う客だ").split

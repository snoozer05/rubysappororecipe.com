Rational(2, 3).to_s    #=> 2/3
Rational(2, 3).inspect #=> (2/3)

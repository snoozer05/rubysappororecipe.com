# (1) 1/3 + 1/5 = 8/15
Rational(1, 3) + Rational(1, 5) #=> (8/15)

# (2) 1/6 * 3/4 = 1/8
Rational(1, 6) * Rational(3, 4) #=> (1/8)

# (3) 4/5 / 2/7 = 14/5
Rational(4, 5) / Rational(2, 7) #=> (14/5)

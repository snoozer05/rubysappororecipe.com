# 分子を取り出す
Rational(2, 3).numerator   #=> 2

# 分母を取り出す
Rational(2, 3).denominator #=> 3

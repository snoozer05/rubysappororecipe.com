Rational(1)    #=> Rational(1, 1) # 1/1 = 1
Rational(1, 3) #=> Rational(1, 3) # 1/3
Rational(3, 3) #=> Rational(1, 1) # 1/1 = 1

require 'rubygems'
require 'vpim/vcard'

vcard = Vpim::Vcard.create
vcard << Vpim::DirectoryInfo::Field.create('N', '島田;浩二')
vcard << Vpim::DirectoryInfo::Field.create('FN', '島田浩二')
vcard << Vpim::DirectoryInfo::Field.create('EMAIL', 'snoozer.05@example.com', 'type' => ['PREF', 'INTERNET'])

File.open('snoozer05.vcf', 'w') {|f| f.write vcard.to_s.gsub(/\r?\n/, "\r\n") }


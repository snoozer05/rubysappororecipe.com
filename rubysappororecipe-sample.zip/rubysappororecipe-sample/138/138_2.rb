require 'rubygems'
require 'vpim/vcard'

open("snoozer05.vcf") do |io|
  vcard = Vpim::Vcard.decode(io).first

  puts vcard.name.fullname
  puts vcard.email
end

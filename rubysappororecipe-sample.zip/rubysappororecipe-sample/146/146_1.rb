require 'rubygems'
require 'haml'

engine = Haml::Engine.new("%p.message Hello, world!")
puts engine.render

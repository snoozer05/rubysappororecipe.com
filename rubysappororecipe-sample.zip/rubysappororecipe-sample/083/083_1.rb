require 'rubygems'
require 'aasm'

class Ticket
  include AASM

  # 初期状態の定義
  aasm_initial_state :new

  # 状態群の定義
  aasm_state :new
  aasm_state :assigned
  aasm_state :closed

  def initialize(args)
    @title, @limit = args[:title], args[:limit]
  end # !> method redefined; discarding old has_rdoc?

  # 現在の状態を返す
  def current_state
    aasm_current_state
  end

  # 状態遷移(new => assigned)
  aasm_event :assign do
    # ここにロジックを記述
    # ...
    # 次状態へ遷移
    transitions :to => :assigned, :from => :new
  end

  # 状態遷移(assigned, new => closed)
  aasm_event :fix do
    # ここにロジックを記述
    # ...
    # 次状態へ遷移
    transitions :to => :closed, :from => [:assigned, :new]
  end
end

t = Ticket.new(:title => "記事の執筆", :limit => Time.local(2009, 3, 30))
t.current_state #=> :new

t.assign        #=> true
t.current_state #=> :assigned
t.fix           #=> true
t.current_state #=> :closed

# 各状態への問い合わせメソッドも動的に追加される
t.assigned?     #=> false
t.closed?       #=> true

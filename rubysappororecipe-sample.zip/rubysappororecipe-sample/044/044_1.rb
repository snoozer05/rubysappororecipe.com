# 月末の日付を取得する
require 'date'
require 'rubygems'
require 'activesupport'

d = Date.today #=> Mon, 16 Mar 2009
d.end_of_month #=> Fri, 31 Jul 2009

# 2009年5月の月末日付を取得
Date.new(2009, 5).end_of_month #=> Sun, 31 May 2009

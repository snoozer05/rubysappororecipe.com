require 'date'
require 'rubygems'
require 'activesupport'

d = Date.today       #=> Mon, 16 Mar 2009

# 月初めの日付を取得
d.beginning_of_month #=> Sun, 01 Mar 2009

# 年初めの日付を取得
d.beginning_of_year  #=> Thu, 01 Jan 2009
